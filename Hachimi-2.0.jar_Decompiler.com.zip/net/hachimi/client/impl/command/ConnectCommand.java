package net.hachimi.client.impl.command;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_1074;
import net.minecraft.class_2172;
import net.minecraft.class_412;
import net.minecraft.class_639;
import net.minecraft.class_642;
import net.minecraft.class_642.class_8678;

public class ConnectCommand extends Command {
   public ConnectCommand() {
      super("Connect", "Connects you to a server", literal("connect"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.then(argument("server", StringArgumentType.string()))).executes((c) -> {
         String serverAddress = StringArgumentType.getString(c, "server");
         if (mc.field_1755 instanceof class_412) {
            ChatUtil.error("Attempt to connect while already connecting");
            return 0;
         } else {
            mc.method_18099();
            mc.method_38932();
            Managers.NETWORK.connect(class_639.method_2950(serverAddress), new class_642(class_1074.method_4662("selectServer.defaultName", new Object[0]), serverAddress, class_8678.field_45611));
            return 1;
         }
      });
   }
}
