package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.mixin.accessor.AccessorMinecraftClient;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;
import net.minecraft.class_442;
import net.minecraft.class_638;

public class LeaveCommand extends Command {
   public LeaveCommand() {
      super("Leave", "Leaves the game without disconnecting from the server", literal("leave"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes((c) -> {
         if (mc.method_1542()) {
            ChatUtil.error("Not connected to a server!");
            return 0;
         } else {
            mc.method_1562().method_47658();
            mc.field_1687 = null;
            mc.field_1724 = null;
            ((AccessorMinecraftClient)mc).hookSetWorld((class_638)null);
            mc.method_29970(new class_442());
            return 1;
         }
      });
   }
}
