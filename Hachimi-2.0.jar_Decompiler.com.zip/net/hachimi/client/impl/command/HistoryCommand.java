package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.PlayerArgumentType;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class HistoryCommand extends Command {
   public HistoryCommand() {
      super("History", "View the name history of a player", literal("history"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("player", PlayerArgumentType.player()).executes((c) -> {
         String playerName = PlayerArgumentType.getPlayer(c, "player");
         UUID uuid = Managers.LOOKUP.getUUIDFromName(playerName);
         if (uuid == null) {
            ChatUtil.error("Could not find player UUID!");
            return 0;
         } else {
            Map<String, String> nameHistory = Managers.LOOKUP.getNameHistoryFromUUID(uuid);
            if (nameHistory == null) {
               ChatUtil.error("Could not find player name history!");
               return 0;
            } else {
               ArrayList<String> nameHistoryList = new ArrayList();

               for(Map.Entry<String, String> entry : nameHistory.entrySet()) {
                  String var10001 = (String)entry.getValue();
                  nameHistoryList.add(var10001 + " - " + ((String)entry.getKey()).substring(0, 10));
               }

               if (nameHistoryList.isEmpty()) {
                  ChatUtil.error("No player name history!");
                  return 0;
               } else {
                  ChatUtil.clientSendMessageRaw("§7History: §f" + String.join(", ", nameHistoryList));
                  return 1;
               }
            }
         }
      }));
   }
}
