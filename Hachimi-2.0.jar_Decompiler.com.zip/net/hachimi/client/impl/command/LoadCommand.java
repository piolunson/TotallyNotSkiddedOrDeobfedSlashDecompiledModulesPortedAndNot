package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class LoadCommand extends Command {
   public LoadCommand() {
      super("Load", "Loads the current config", literal("load"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes((c) -> {
         Hachimi.CONFIG.loadClientModules();
         ChatUtil.clientSendMessage("Loaded client config!");
         return 1;
      });
   }
}
