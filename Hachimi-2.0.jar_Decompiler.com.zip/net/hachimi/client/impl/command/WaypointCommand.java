package net.hachimi.client.impl.command;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.waypoint.UserWaypoint;
import net.hachimi.client.api.waypoint.Waypoint;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.chat.ChatUtil;
import net.hachimi.client.util.world.DimensionUtil;
import net.minecraft.class_2172;

public class WaypointCommand extends Command {
   public WaypointCommand() {
      super("Waypoint", "Adds/Removes a waypoint", literal("waypoint"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      ((LiteralArgumentBuilder)builder.then(((RequiredArgumentBuilder)argument("add/del", StringArgumentType.string()).suggests(suggest(new String[]{"add", "del", "delete", "remove"})).then(((RequiredArgumentBuilder)argument("waypoint", StringArgumentType.string()).then(argument("x", DoubleArgumentType.doubleArg()).then(argument("y", DoubleArgumentType.doubleArg()).then(argument("z", DoubleArgumentType.doubleArg()).executes((c) -> {
         String waypointName = StringArgumentType.getString(c, "waypoint");
         double x = DoubleArgumentType.getDouble(c, "x");
         double y = DoubleArgumentType.getDouble(c, "y");
         double z = DoubleArgumentType.getDouble(c, "z");
         String action = StringArgumentType.getString(c, "add/del");
         if (action.equalsIgnoreCase("add")) {
            if (Managers.WAYPOINT.contains(waypointName)) {
               ChatUtil.error("Waypoint already exist!");
               return 0;
            }

            ChatUtil.clientSendMessage("Added waypoint with name §s" + waypointName);
            Managers.WAYPOINT.register((Waypoint)(new UserWaypoint(waypointName, mc.method_1542() ? "Singleplayer" : Managers.NETWORK.getServerIp(), DimensionUtil.getDimension(), x, y, z)));
         }

         return 1;
      }))))).executes((c) -> {
         String waypointName = StringArgumentType.getString(c, "waypoint");
         String action = StringArgumentType.getString(c, "add/del");
         if (action.equalsIgnoreCase("remove") || action.equalsIgnoreCase("del") || action.equalsIgnoreCase("delete")) {
            if (!Managers.WAYPOINT.contains(waypointName)) {
               ChatUtil.error("Waypoint does not exist!");
               return 0;
            }

            ChatUtil.clientSendMessage("Removed waypoint with name §c" + waypointName);
            Managers.WAYPOINT.remove(waypointName);
         }

         return 1;
      }))).executes((c) -> {
         ChatUtil.error("Must provide waypoint name!");
         return 1;
      }))).executes((c) -> {
         ChatUtil.error("Invalid usage! Usage: " + this.getUsage());
         return 1;
      });
   }
}
