package net.hachimi.client.impl.command;

import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class YawCommand extends Command {
   public YawCommand() {
      super("Yaw", "Sets the player yaw", literal("yaw"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("yaw", FloatArgumentType.floatArg()).executes((c) -> {
         float yaw = FloatArgumentType.getFloat(c, "yaw");
         mc.field_1724.method_36456(yaw);
         mc.field_1724.method_5847(yaw);
         mc.field_1724.method_5636(yaw);
         ChatUtil.clientSendMessage("Set player yaw to §s" + yaw);
         return 1;
      }));
   }
}
