package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.ModuleArgumentType;
import net.hachimi.client.api.module.Module;
import net.hachimi.client.api.module.ToggleModule;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;

public class NotifyCommand extends Command {
   public NotifyCommand() {
      super("Notify", "Notifies in chat when a module is toggled", literal("notify"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("module", ModuleArgumentType.module()).executes((c) -> {
         Module module = ModuleArgumentType.getModule(c, "module");
         if (module instanceof ToggleModule t) {
            t.setNotify(!t.getNotify());
            if (t.getNotify()) {
               ChatUtil.clientSendMessage("Added §7" + t.getName() + "§f notifications to chat");
            } else {
               ChatUtil.clientSendMessage("Removed §7" + t.getName() + "§f notifications from chat");
            }

            return 1;
         } else {
            ChatUtil.error("Invalid module!");
            return 0;
         }
      }));
   }
}
