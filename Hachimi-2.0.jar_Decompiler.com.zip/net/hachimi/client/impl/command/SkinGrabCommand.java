package net.hachimi.client.impl.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.command.Command;
import net.hachimi.client.api.command.PlayerArgumentType;
import net.hachimi.client.util.chat.ChatUtil;
import net.minecraft.class_2172;
import net.minecraft.class_640;

public class SkinGrabCommand extends Command {
   public SkinGrabCommand() {
      super("SkinGrab", "Downloads player skins", literal("skingrab"));
   }

   public void buildCommand(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(argument("player", PlayerArgumentType.player()).executes((c) -> {
         String player = PlayerArgumentType.getPlayer(c, "player");
         String skinTexture = null;

         for(class_640 playerListEntry : mc.field_1724.field_3944.method_2880()) {
            String playerName = playerListEntry.method_2966().getName();
            if (player.equals(playerName)) {
               skinTexture = playerListEntry.method_52810().comp_1911();
               break;
            }
         }

         if (skinTexture == null) {
            ChatUtil.error("Failed to find skin texture for " + player);
            return 0;
         } else {
            try {
               URL url = new URL(skinTexture);
               HttpURLConnection connection = (HttpURLConnection)url.openConnection();
               InputStream inputStream = connection.getInputStream();
               String var10002 = Hachimi.CONFIG.getClientDirectory().toString();
               FileOutputStream outputStream = new FileOutputStream(var10002 + "/" + player + ".png");
               if (connection.getResponseCode() != 200) {
                  return 0;
               }

               outputStream.write(inputStream.readAllBytes());
               ChatUtil.clientSendMessage(player + " skin downloaded to client folder");
            } catch (IOException var7) {
               ChatUtil.error("Failed to download skin texture for " + player);
            }

            return 1;
         }
      }));
   }
}
