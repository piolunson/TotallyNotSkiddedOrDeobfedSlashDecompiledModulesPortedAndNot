package net.hachimi.client.impl.event.network;

import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1268;
import net.minecraft.class_1799;

public class SetCurrentHandEvent extends Event implements Globals {
   private final class_1268 hand;

   public SetCurrentHandEvent(class_1268 hand) {
      this.hand = hand;
   }

   public class_1268 getHand() {
      return this.hand;
   }

   public class_1799 getStackInHand() {
      return mc.field_1724.method_5998(this.hand);
   }
}
