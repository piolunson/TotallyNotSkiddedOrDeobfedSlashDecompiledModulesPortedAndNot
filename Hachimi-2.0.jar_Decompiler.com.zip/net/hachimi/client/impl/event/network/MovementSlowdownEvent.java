package net.hachimi.client.impl.event.network;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_744;

public class MovementSlowdownEvent extends Event {
   public final class_744 input;

   public MovementSlowdownEvent(class_744 input) {
      this.input = input;
   }

   public class_744 getInput() {
      return this.input;
   }
}
