package net.hachimi.client.impl.event;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_437;

public class ScreenOpenEvent extends Event {
   private final class_437 screen;

   public ScreenOpenEvent(class_437 screen) {
      this.screen = screen;
   }

   public class_437 getScreen() {
      return this.screen;
   }
}
