package net.hachimi.client.impl.event.world;

import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1297;

public class RemoveEntityEvent extends Event implements Globals {
   private final class_1297 entity;
   private final class_1297.class_5529 removalReason;

   public RemoveEntityEvent(class_1297 entity, class_1297.class_5529 removalReason) {
      this.entity = entity;
      this.removalReason = removalReason;
   }

   public class_1297 getEntity() {
      return this.entity;
   }

   public class_1297.class_5529 getRemovalReason() {
      return this.removalReason;
   }
}
