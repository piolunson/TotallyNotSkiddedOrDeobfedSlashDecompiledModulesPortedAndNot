package net.hachimi.client.impl.event.world;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2338;
import net.minecraft.class_2818;

public class UnloadChunkBlocksEvent extends Event {
   private final class_2818 chunk;

   public UnloadChunkBlocksEvent(class_2818 chunk) {
      this.chunk = chunk;
   }

   public boolean contains(class_2338 blockPos) {
      int chunkX = blockPos.method_10263() >> 4;
      int chunkZ = blockPos.method_10260() >> 4;
      return chunkX == this.chunk.method_12004().field_9181 && chunkZ == this.chunk.method_12004().field_9180;
   }
}
