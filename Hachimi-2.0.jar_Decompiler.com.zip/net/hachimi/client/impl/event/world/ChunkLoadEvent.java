package net.hachimi.client.impl.event.world;

import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1923;

public class ChunkLoadEvent extends StageEvent {
   private final class_1923 pos;

   public ChunkLoadEvent(class_1923 pos) {
      this.pos = pos;
   }

   public class_1923 getPos() {
      return this.pos;
   }
}
