package net.hachimi.client.impl.event.world;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1297;

public final class UpdateCrosshairTargetEvent extends Event {
   private final float tickDelta;
   private final class_1297 cameraEntity;

   public UpdateCrosshairTargetEvent(float tickDelta, class_1297 cameraEntity) {
      this.tickDelta = tickDelta;
      this.cameraEntity = cameraEntity;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public class_1297 getCameraEntity() {
      return this.cameraEntity;
   }
}
