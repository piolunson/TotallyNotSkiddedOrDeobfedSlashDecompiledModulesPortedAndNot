package net.hachimi.client.impl.event.gui.hud;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_303;

@Cancelable
public class RenderChatHudEvent extends Event {
   private final class_303.class_7590 chatHudLine;
   private double animation;
   private boolean animationMode;

   public RenderChatHudEvent(class_303.class_7590 chatHudLine) {
      this.chatHudLine = chatHudLine;
   }

   public double getAnimation() {
      return this.animation;
   }

   public void setAnimation(double animation) {
      this.animation = animation;
   }

   public void setSlide(boolean animationMode) {
      this.animationMode = animationMode;
   }

   public class_303.class_7590 getChatHudLine() {
      return this.chatHudLine;
   }

   public boolean getAnimationMode() {
      return this.animationMode;
   }
}
