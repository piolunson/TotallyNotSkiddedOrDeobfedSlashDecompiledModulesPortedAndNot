package net.hachimi.client.impl.event.gui.hud;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_5481;

@Cancelable
public class ChatTextEvent extends Event {
   private class_5481 text;

   public ChatTextEvent(class_5481 text) {
      this.text = text;
   }

   public void setText(class_5481 text) {
      this.text = text;
   }

   public class_5481 getText() {
      return this.text;
   }
}
