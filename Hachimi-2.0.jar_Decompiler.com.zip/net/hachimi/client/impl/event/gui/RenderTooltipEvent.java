package net.hachimi.client.impl.event.gui;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_1799;
import net.minecraft.class_332;

@Cancelable
public class RenderTooltipEvent extends StageEvent {
   public final class_332 context;
   private final class_1799 stack;
   private final int x;
   private final int y;

   public RenderTooltipEvent(class_332 context, class_1799 stack, int x, int y) {
      this.context = context;
      this.stack = stack;
      this.x = x;
      this.y = y;
   }

   public class_332 getContext() {
      return this.context;
   }

   public class_1799 getStack() {
      return this.stack;
   }

   public int getX() {
      return this.x;
   }

   public int getY() {
      return this.y;
   }
}
