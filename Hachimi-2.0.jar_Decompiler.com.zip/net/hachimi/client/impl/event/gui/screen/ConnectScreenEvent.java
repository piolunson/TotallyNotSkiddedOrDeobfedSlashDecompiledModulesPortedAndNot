package net.hachimi.client.impl.event.gui.screen;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_639;
import net.minecraft.class_642;

public class ConnectScreenEvent extends Event {
   private final class_639 address;
   private final class_642 info;

   public ConnectScreenEvent(class_639 address, class_642 info) {
      this.address = address;
      this.info = info;
   }

   public class_639 getAddress() {
      return this.address;
   }

   public class_642 getInfo() {
      return this.info;
   }
}
