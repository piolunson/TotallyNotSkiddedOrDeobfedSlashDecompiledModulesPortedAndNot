package net.hachimi.client.impl.event.block;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2248;

@Cancelable
public class BlockSlipperinessEvent extends Event {
   private final class_2248 block;
   private float slipperiness;

   public BlockSlipperinessEvent(class_2248 block, float slipperiness) {
      this.block = block;
      this.slipperiness = slipperiness;
   }

   public class_2248 getBlock() {
      return this.block;
   }

   public float getSlipperiness() {
      return this.slipperiness;
   }

   public void setSlipperiness(float slipperiness) {
      this.slipperiness = slipperiness;
   }
}
