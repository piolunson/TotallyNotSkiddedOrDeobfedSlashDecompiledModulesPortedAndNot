package net.hachimi.client.impl.event;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1041;

public class ResolutionEvent extends Event {
   private final class_1041 window;

   public ResolutionEvent(class_1041 window) {
      this.window = window;
   }

   public class_1041 getWindow() {
      return this.window;
   }
}
