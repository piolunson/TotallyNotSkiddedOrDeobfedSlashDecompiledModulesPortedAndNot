package net.hachimi.client.impl.event.render;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1297;

@Cancelable
public class RenderEntityInWorldEvent extends Event {
   private final class_1297 entityType;

   public RenderEntityInWorldEvent(class_1297 entityType) {
      this.entityType = entityType;
   }

   public class_1297 getEntity() {
      return this.entityType;
   }
}
