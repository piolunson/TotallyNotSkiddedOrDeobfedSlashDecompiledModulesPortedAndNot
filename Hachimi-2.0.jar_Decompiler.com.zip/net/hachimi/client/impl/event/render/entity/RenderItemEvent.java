package net.hachimi.client.impl.event.render.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1542;

@Cancelable
public class RenderItemEvent extends Event {
   private final class_1542 itemEntity;

   public RenderItemEvent(class_1542 itemEntity) {
      this.itemEntity = itemEntity;
   }

   public class_1542 getItem() {
      return this.itemEntity;
   }
}
