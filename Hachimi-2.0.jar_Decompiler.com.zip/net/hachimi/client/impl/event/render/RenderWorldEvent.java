package net.hachimi.client.impl.event.render;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_4587;

public class RenderWorldEvent extends Event {
   private final class_4587 matrices;
   private final float tickDelta;

   public RenderWorldEvent(class_4587 matrices, float tickDelta) {
      this.matrices = matrices;
      this.tickDelta = tickDelta;
   }

   public class_4587 getMatrices() {
      return this.matrices;
   }

   public float getTickDelta() {
      return this.tickDelta;
   }

   public static class Game extends RenderWorldEvent {
      public Game(class_4587 matrices, float tickDelta) {
         super(matrices, tickDelta);
      }
   }

   public static class Hand extends RenderWorldEvent {
      public Hand(class_4587 matrices, float tickDelta) {
         super(matrices, tickDelta);
      }
   }
}
