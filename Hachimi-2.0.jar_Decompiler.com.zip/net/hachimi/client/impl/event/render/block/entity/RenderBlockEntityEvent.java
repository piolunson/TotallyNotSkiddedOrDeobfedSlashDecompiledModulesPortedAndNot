package net.hachimi.client.impl.event.render.block.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

public class RenderBlockEntityEvent extends Event {
   private final class_2586 blockEntity;

   public RenderBlockEntityEvent(class_2586 blockEntity) {
      this.blockEntity = blockEntity;
   }

   public class_2338 getPos() {
      return this.blockEntity.method_11016();
   }

   public class_2586 getBlockEntity() {
      return this.blockEntity;
   }

   public class_2680 getCachedState() {
      return this.blockEntity.method_11010();
   }
}
