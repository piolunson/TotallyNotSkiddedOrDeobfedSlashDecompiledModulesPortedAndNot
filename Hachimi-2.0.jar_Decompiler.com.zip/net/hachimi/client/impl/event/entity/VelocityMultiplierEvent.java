package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

@Cancelable
public class VelocityMultiplierEvent extends Event {
   private final class_2680 state;

   public VelocityMultiplierEvent(class_2680 state) {
      this.state = state;
   }

   public class_2248 getBlock() {
      return this.state.method_26204();
   }
}
