package net.hachimi.client.impl.event.entity.player;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.StageEvent;
import net.minecraft.class_243;

@Cancelable
public class TravelEvent extends StageEvent {
   private final class_243 movementInput;

   public TravelEvent(class_243 movementInput) {
      this.movementInput = movementInput;
   }

   public class_243 getMovementInput() {
      return this.movementInput;
   }
}
