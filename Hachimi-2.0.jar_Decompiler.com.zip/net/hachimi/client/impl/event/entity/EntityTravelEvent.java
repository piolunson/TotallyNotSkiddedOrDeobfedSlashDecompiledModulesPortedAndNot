package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1309;

@Cancelable
public class EntityTravelEvent extends Event {
   private final class_1309 entity;
   private final boolean pre;

   public EntityTravelEvent(class_1309 entity, boolean pre) {
      this.entity = entity;
      this.pre = pre;
   }

   public class_1309 getEntity() {
      return this.entity;
   }

   public boolean isPre() {
      return this.pre;
   }
}
