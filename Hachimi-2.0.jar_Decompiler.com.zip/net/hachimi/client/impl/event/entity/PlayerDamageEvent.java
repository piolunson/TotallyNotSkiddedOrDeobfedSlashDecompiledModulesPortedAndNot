package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1309;

public class PlayerDamageEvent extends Event {
   private final class_1309 damaged;

   public PlayerDamageEvent(class_1309 damaged) {
      this.damaged = damaged;
   }

   public class_1309 getDamaged() {
      return this.damaged;
   }
}
