package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_6880;

public class StatusEffectEvent extends Event {
   private final class_1293 statusEffectInstance;

   public StatusEffectEvent(class_1293 statusEffectInstance) {
      this.statusEffectInstance = statusEffectInstance;
   }

   public class_1293 getStatusEffect() {
      return this.statusEffectInstance;
   }

   public static class Add extends StatusEffectEvent {
      public Add(class_1293 statusEffectInstance) {
         super(statusEffectInstance);
      }
   }

   public static class Remove extends StatusEffectEvent {
      private final class_6880<class_1291> type;

      public Remove(class_6880<class_1291> type) {
         super((class_1293)null);
         this.type = type;
      }

      public class_6880<class_1291> getType() {
         return this.type;
      }
   }
}
