package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_238;

public class SetBBEvent extends Event {
   private final class_238 boundingBox;

   public SetBBEvent(class_238 boundingBox) {
      this.boundingBox = boundingBox;
   }

   public class_238 getBoundingBox() {
      return this.boundingBox;
   }
}
