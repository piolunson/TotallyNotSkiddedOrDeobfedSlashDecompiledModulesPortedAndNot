package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class ConsumeItemEvent extends Event {
   private final class_1799 activeItemStack;

   public ConsumeItemEvent(class_1799 activeItemStack) {
      this.activeItemStack = activeItemStack;
   }

   public class_1799 getStack() {
      return this.activeItemStack;
   }

   public class_1792 getItem() {
      return this.activeItemStack.method_7909();
   }
}
