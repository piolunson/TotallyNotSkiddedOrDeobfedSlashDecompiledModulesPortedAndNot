package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1309;

public class UpdateServerPositionEvent extends Event {
   private final class_1309 livingEntity;
   private final double x;
   private final double y;
   private final double z;
   private final float yaw;
   private final float pitch;

   public UpdateServerPositionEvent(class_1309 livingEntity, double x, double y, double z, float yaw, float pitch) {
      this.livingEntity = livingEntity;
      this.x = x;
      this.y = y;
      this.z = z;
      this.yaw = yaw;
      this.pitch = pitch;
   }

   public class_1309 getLivingEntity() {
      return this.livingEntity;
   }

   public double getX() {
      return this.x;
   }

   public double getY() {
      return this.y;
   }

   public double getZ() {
      return this.z;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }
}
