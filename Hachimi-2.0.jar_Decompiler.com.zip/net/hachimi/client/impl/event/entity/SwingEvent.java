package net.hachimi.client.impl.event.entity;

import net.hachimi.eventbus.annotation.Cancelable;
import net.hachimi.eventbus.event.Event;
import net.minecraft.class_1268;

@Cancelable
public class SwingEvent extends Event {
   private final class_1268 hand;

   public SwingEvent(class_1268 hand) {
      this.hand = hand;
   }

   public class_1268 getHand() {
      return this.hand;
   }
}
