package net.hachimi.client.impl.imixin;

import net.hachimi.client.util.network.InteractType;
import net.minecraft.class_1297;

@IMixin
public interface IPlayerInteractEntityC2SPacket {
   class_1297 getEntity();

   InteractType getType();
}
