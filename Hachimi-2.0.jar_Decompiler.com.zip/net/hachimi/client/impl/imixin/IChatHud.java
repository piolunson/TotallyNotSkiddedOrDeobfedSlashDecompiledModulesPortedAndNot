package net.hachimi.client.impl.imixin;

import net.minecraft.class_2561;
import net.minecraft.class_7591;

@IMixin
public interface IChatHud {
   void addMessage(class_2561 var1, class_7591 var2, int var3);
}
