package net.hachimi.client.impl.imixin;

import net.minecraft.class_2596;

@IMixin
public interface IClientPlayNetworkHandler {
   void sendQuietPacket(class_2596<?> var1);
}
