package net.hachimi.client.impl.imixin;

import net.minecraft.class_276;

@IMixin
public interface IPostEffectProcessor {
   void overwriteBuffer(String var1, class_276 var2);
}
