package net.hachimi.client.mixin.sound;

import java.util.Map;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import net.minecraft.class_4235;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin({class_1140.class})
public class MixinSoundSystem {
   @Shadow
   private boolean field_5563;
   @Shadow
   private int field_5550;
   @Shadow
   @Final
   private Map<class_1113, Integer> field_18952;
   @Shadow
   @Final
   private Map<class_1113, class_4235.class_4236> field_18950;
}
