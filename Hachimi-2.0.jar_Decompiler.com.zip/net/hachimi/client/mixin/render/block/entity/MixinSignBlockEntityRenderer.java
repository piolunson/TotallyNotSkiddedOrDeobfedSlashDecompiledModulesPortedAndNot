package net.hachimi.client.mixin.render.block.entity;

import net.hachimi.client.impl.event.render.block.entity.RenderSignTextEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_8242;
import net.minecraft.class_837;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_837.class})
public class MixinSignBlockEntityRenderer {
   @Inject(
      method = {"renderText"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookRenderText(class_2338 pos, class_8242 signText, class_4587 matrices, class_4597 vertexConsumers, int light, int lineHeight, int lineWidth, boolean front, CallbackInfo ci) {
      RenderSignTextEvent renderSignTextEvent = new RenderSignTextEvent();
      EventBus.INSTANCE.dispatch(renderSignTextEvent);
      if (renderSignTextEvent.isCanceled()) {
         ci.cancel();
      }

   }
}
