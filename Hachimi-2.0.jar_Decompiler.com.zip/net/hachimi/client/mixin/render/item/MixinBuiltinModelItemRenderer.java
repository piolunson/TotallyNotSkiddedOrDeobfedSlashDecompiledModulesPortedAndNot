package net.hachimi.client.mixin.render.item;

import com.google.common.collect.Maps;
import java.util.Map;
import net.hachimi.client.api.render.layers.RenderLayersClient;
import net.minecraft.class_1068;
import net.minecraft.class_1071;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_2484;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_756;
import net.minecraft.class_9296;
import net.minecraft.class_2484.class_2486;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_756.class})
public class MixinBuiltinModelItemRenderer {
   @Unique
   private static final Map<class_2484.class_2485, class_2960> TEXTURES = (Map)class_156.method_654(Maps.newHashMap(), (map) -> {
      map.put(class_2486.field_11512, class_2960.method_60654("textures/entity/skeleton/skeleton.png"));
      map.put(class_2486.field_11513, class_2960.method_60654("textures/entity/skeleton/wither_skeleton.png"));
      map.put(class_2486.field_11508, class_2960.method_60654("textures/entity/zombie/zombie.png"));
      map.put(class_2486.field_11507, class_2960.method_60654("textures/entity/creeper/creeper.png"));
      map.put(class_2486.field_11511, class_2960.method_60654("textures/entity/enderdragon/dragon.png"));
      map.put(class_2486.field_41313, class_2960.method_60654("textures/entity/piglin/piglin.png"));
      map.put(class_2486.field_11510, class_1068.method_4649());
   });

   @Redirect(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/block/entity/SkullBlockEntityRenderer;getRenderLayer(Lnet/minecraft/block/SkullBlock$SkullType;Lnet/minecraft/component/type/ProfileComponent;)Lnet/minecraft/client/render/RenderLayer;"
)
   )
   public class_1921 hookGetRenderLayer(class_2484.class_2485 type, class_9296 profile) {
      class_2960 identifier = (class_2960)TEXTURES.get(type);
      if (type == class_2486.field_11510 && profile != null) {
         class_1071 playerSkinProvider = class_310.method_1551().method_1582();
         return (class_1921)RenderLayersClient.ENTITY_TRANSLUCENT.apply(playerSkinProvider.method_52862(profile.comp_2413()).comp_1626(), true);
      } else {
         return (class_1921)RenderLayersClient.ENTITY_CUTOUT_NO_CULL_Z_OFFSET.apply(identifier, true);
      }
   }
}
