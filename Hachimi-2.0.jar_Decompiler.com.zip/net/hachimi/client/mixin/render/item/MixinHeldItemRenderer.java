package net.hachimi.client.mixin.render.item;

import net.hachimi.client.impl.event.render.item.EatTransformationEvent;
import net.hachimi.client.impl.event.render.item.RenderArmEvent;
import net.hachimi.client.impl.event.render.item.RenderFirstPersonEvent;
import net.hachimi.client.impl.event.render.item.RenderSwingAnimationEvent;
import net.hachimi.client.impl.event.render.item.UpdateHeldItemsEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1007;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_759.class})
public class MixinHeldItemRenderer implements Globals {
   @Shadow
   @Final
   private class_898 field_4046;
   @Shadow
   @Final
   private class_310 field_4050;
   @Shadow
   private class_1799 field_4047;
   @Shadow
   private class_1799 field_4048;
   @Shadow
   public float field_4043;
   @Shadow
   public float field_4052;
   @Shadow
   public float field_4053;
   @Shadow
   public float field_4051;

   @Inject(
      method = {"renderArmHoldingItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookRenderArm(class_4587 matrices, class_4597 vertexConsumers, int light, float equipProgress, float swingProgress, class_1306 arm, CallbackInfo ci) {
      class_1007 playerEntityRenderer = (class_1007)this.field_4046.method_3953(this.field_4050.field_1724);
      RenderArmEvent renderArmEvent = new RenderArmEvent(matrices, vertexConsumers, light, equipProgress, swingProgress, arm, playerEntityRenderer);
      EventBus.INSTANCE.dispatch(renderArmEvent);
      if (renderArmEvent.isCanceled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"renderFirstPersonItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookRenderFirstPersonItem$2(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
      RenderFirstPersonEvent.Head renderFirstPersonEvent = new RenderFirstPersonEvent.Head(hand, item, equipProgress, matrices);
      EventBus.INSTANCE.dispatch(renderFirstPersonEvent);
      if (renderFirstPersonEvent.isCanceled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"renderFirstPersonItem"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"
)}
   )
   private void hookRenderFirstPersonItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
      RenderFirstPersonEvent renderFirstPersonEvent = new RenderFirstPersonEvent(hand, item, equipProgress, matrices);
      EventBus.INSTANCE.dispatch(renderFirstPersonEvent);
   }

   @Inject(
      method = {"applyEatOrDrinkTransformation"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookApplyEatOrDrinkTransformation(class_4587 matrices, float tickDelta, class_1306 arm, class_1799 stack, class_1657 player, CallbackInfo ci) {
      ci.cancel();
      float f = (float)this.field_4050.field_1724.method_6014() - tickDelta + 1.0F;
      float g = f / (float)stack.method_7935(mc.field_1724);
      if (g < 0.8F) {
         float h = class_3532.method_15379(class_3532.method_15362(f / 4.0F * (float)Math.PI) * 0.1F);
         EatTransformationEvent eatTransformationEvent = new EatTransformationEvent();
         EventBus.INSTANCE.dispatch(eatTransformationEvent);
         matrices.method_46416(0.0F, eatTransformationEvent.isCanceled() ? h * eatTransformationEvent.getFactor() : h, 0.0F);
      }

      float h = 1.0F - (float)Math.pow((double)g, (double)27.0F);
      int i = arm == class_1306.field_6183 ? 1 : -1;
      matrices.method_46416(h * 0.6F * (float)i, h * -0.5F, h * 0.0F);
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * h * 90.0F));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(h * 10.0F));
      matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * h * 30.0F));
   }

   @ModifyArg(
      method = {"updateHeldItems"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/util/math/MathHelper;clamp(FFF)F",
   ordinal = 2
),
      index = 0
   )
   private float hookEquipProgressMainhand(float value) {
      RenderSwingAnimationEvent renderSwingAnimation = new RenderSwingAnimationEvent();
      EventBus.INSTANCE.dispatch(renderSwingAnimation);
      float f = mc.field_1724.method_7261(1.0F);
      float modified = renderSwingAnimation.isCanceled() ? 1.0F : f * f * f;
      return (class_1799.method_7973(this.field_4047, mc.field_1724.method_6047()) ? modified : 0.0F) - this.field_4043;
   }

   @Inject(
      method = {"updateHeldItems"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookUpdateHeldItems(CallbackInfo ci) {
      class_1799 itemStack = mc.field_1724.method_6047();
      class_1799 itemStack2 = mc.field_1724.method_6079();
      UpdateHeldItemsEvent updateHeldItemsEvent = new UpdateHeldItemsEvent();
      EventBus.INSTANCE.dispatch(updateHeldItemsEvent);
      if (updateHeldItemsEvent.isCanceled()) {
         ci.cancel();
         this.field_4043 = 1.0F;
         this.field_4052 = 1.0F;
         this.field_4053 = 1.0F;
         this.field_4051 = 1.0F;
         this.field_4047 = itemStack;
         this.field_4048 = itemStack2;
      }

   }
}
