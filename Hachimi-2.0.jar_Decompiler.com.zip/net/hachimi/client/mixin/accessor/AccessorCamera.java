package net.hachimi.client.mixin.accessor;

import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_4184.class})
public interface AccessorCamera {
   @Accessor("cameraY")
   float getCameraY();

   @Accessor("lastCameraY")
   float getLastCameraY();
}
