package net.hachimi.client.mixin.accessor;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_636.class})
public interface AccessorClientPlayerInteractionManager {
   @Invoker("syncSelectedSlot")
   void hookSyncSelectedSlot();

   @Invoker("interactBlockInternal")
   class_1269 hookInteractBlockInternal(class_746 var1, class_1268 var2, class_3965 var3);

   @Accessor("currentBreakingProgress")
   float hookGetCurrentBreakingProgress();

   @Accessor("currentBreakingProgress")
   void hookSetCurrentBreakingProgress(float var1);
}
