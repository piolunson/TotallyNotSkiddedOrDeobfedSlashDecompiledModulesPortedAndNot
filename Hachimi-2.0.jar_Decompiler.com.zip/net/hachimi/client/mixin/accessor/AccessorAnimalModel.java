package net.hachimi.client.mixin.accessor;

import net.minecraft.class_4592;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_4592.class})
public interface AccessorAnimalModel {
   @Invoker("getBodyParts")
   Iterable<class_630> hookGetBodyParts();

   @Invoker("getHeadParts")
   Iterable<class_630> hookGetHeadParts();

   @Accessor("headScaled")
   boolean hookGetHeadScaled();

   @Accessor("invertedChildHeadScale")
   float hookGetInvertedChildHeadScale();

   @Accessor("invertedChildBodyScale")
   float hookGetInvertedChildBodyScale();

   @Accessor("childHeadYOffset")
   float hookGetChildHeadYOffset();

   @Accessor("childHeadZOffset")
   float hookGetChildHeadZOffset();

   @Accessor("childBodyYOffset")
   float hookGetChildBodyYOffset();
}
