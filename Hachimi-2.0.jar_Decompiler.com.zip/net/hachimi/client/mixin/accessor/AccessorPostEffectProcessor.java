package net.hachimi.client.mixin.accessor;

import java.util.List;
import net.minecraft.class_279;
import net.minecraft.class_283;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_279.class})
public interface AccessorPostEffectProcessor {
   @Accessor("passes")
   List<class_283> hookGetPasses();
}
