package net.hachimi.client.mixin.accessor;

import net.minecraft.class_2833;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2833.class})
public interface AccessorVehicleMoveC2SPacket {
   @Accessor("y")
   void hookSetY(double var1);
}
