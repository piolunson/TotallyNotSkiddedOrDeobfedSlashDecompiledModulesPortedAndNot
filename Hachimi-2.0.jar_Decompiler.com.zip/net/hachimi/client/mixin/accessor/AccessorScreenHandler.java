package net.hachimi.client.mixin.accessor;

import net.minecraft.class_1703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1703.class})
public interface AccessorScreenHandler {
   @Accessor("revision")
   void hookSetRevision(int var1);
}
