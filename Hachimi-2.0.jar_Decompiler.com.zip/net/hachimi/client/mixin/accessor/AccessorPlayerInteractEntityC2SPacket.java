package net.hachimi.client.mixin.accessor;

import net.minecraft.class_2824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_2824.class})
public interface AccessorPlayerInteractEntityC2SPacket {
   @Accessor("entityId")
   @Mutable
   void hookSetEntityId(int var1);
}
