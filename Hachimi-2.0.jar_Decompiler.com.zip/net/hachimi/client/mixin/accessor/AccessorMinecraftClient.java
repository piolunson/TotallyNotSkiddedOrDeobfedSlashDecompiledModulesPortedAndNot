package net.hachimi.client.mixin.accessor;

import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_310.class})
public interface AccessorMinecraftClient {
   @Accessor("itemUseCooldown")
   void hookSetItemUseCooldown(int var1);

   @Accessor("itemUseCooldown")
   int hookGetItemUseCooldown();

   @Accessor("attackCooldown")
   void hookSetAttackCooldown(int var1);

   @Invoker("doItemUse")
   void hookDoItemUse();

   @Accessor("session")
   @Final
   @Mutable
   void setSession(class_320 var1);

   @Accessor("world")
   void hookSetWorld(class_638 var1);

   @Accessor("disconnecting")
   void hookSetDisconnecting(boolean var1);
}
