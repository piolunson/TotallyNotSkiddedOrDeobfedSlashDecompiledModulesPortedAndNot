package net.hachimi.client.mixin.biome;

import net.hachimi.client.impl.event.biome.BiomeColorEvent;
import net.hachimi.client.impl.event.world.SkyboxEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1959;
import net.minecraft.class_4763;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1959.class})
public class MixinBiome {
   @Shadow
   @Final
   private class_4763 field_22039;

   @Inject(
      method = {"getFogColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookGetFogColor(CallbackInfoReturnable<Integer> cir) {
      SkyboxEvent.Fog skyboxEvent = new SkyboxEvent.Fog(0.0F);
      EventBus.INSTANCE.dispatch(skyboxEvent);
      if (skyboxEvent.isCanceled()) {
         cir.cancel();
         cir.setReturnValue(skyboxEvent.getRGB());
      }

   }

   @Inject(
      method = {"getWaterColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookGetWaterColor(CallbackInfoReturnable<Integer> cir) {
      BiomeColorEvent.Water waterEvent = new BiomeColorEvent.Water();
      EventBus.INSTANCE.dispatch(waterEvent);
      if (waterEvent.isCanceled()) {
         cir.cancel();
         cir.setReturnValue(waterEvent.getColor());
      }

   }

   @Inject(
      method = {"getWaterFogColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookGetWaterFogColor(CallbackInfoReturnable<Integer> cir) {
      BiomeColorEvent.Water waterEvent = new BiomeColorEvent.Water();
      EventBus.INSTANCE.dispatch(waterEvent);
      if (waterEvent.isCanceled()) {
         cir.cancel();
         cir.setReturnValue(waterEvent.getColor());
      }

   }

   @Inject(
      method = {"getGrassColorAt"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookGetGrassColorAt(double x, double z, CallbackInfoReturnable<Integer> cir) {
      BiomeColorEvent.Grass grassEvent = new BiomeColorEvent.Grass();
      EventBus.INSTANCE.dispatch(grassEvent);
      if (grassEvent.isCanceled()) {
         cir.cancel();
         int i = this.field_22039.method_30814().method_30823(x, z, grassEvent.getColor());
         cir.setReturnValue(i);
      }

   }

   @Inject(
      method = {"getDefaultGrassColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookGetDefaultGrassColor(CallbackInfoReturnable<Integer> cir) {
      BiomeColorEvent.Grass grassEvent = new BiomeColorEvent.Grass();
      EventBus.INSTANCE.dispatch(grassEvent);
      if (grassEvent.isCanceled()) {
         cir.cancel();
         cir.setReturnValue(grassEvent.getColor());
      }

   }

   @Inject(
      method = {"getFoliageColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookGetFoliageColor(CallbackInfoReturnable<Integer> cir) {
      BiomeColorEvent.Foliage foliageEvent = new BiomeColorEvent.Foliage();
      EventBus.INSTANCE.dispatch(foliageEvent);
      if (foliageEvent.isCanceled()) {
         cir.cancel();
         cir.setReturnValue(foliageEvent.getColor());
      }

   }
}
