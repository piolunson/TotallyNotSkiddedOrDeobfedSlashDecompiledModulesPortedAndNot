package net.hachimi.client.mixin.color.world;

import net.hachimi.client.impl.event.color.world.BiomeColorEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1163;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_6539;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1163.class})
public class MixinBiomeColors implements Globals {
   @Inject(
      method = {"getColor"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void hookGetColor(class_1920 world, class_2338 pos, class_6539 resolver, CallbackInfoReturnable<Integer> cir) {
      if (mc.field_1687 != null) {
         BiomeColorEvent biomeColorEvent = new BiomeColorEvent(resolver);
         EventBus.INSTANCE.dispatch(biomeColorEvent);
         if (biomeColorEvent.isCanceled()) {
            cir.cancel();
            cir.setReturnValue(biomeColorEvent.getRGB());
         }

      }
   }
}
