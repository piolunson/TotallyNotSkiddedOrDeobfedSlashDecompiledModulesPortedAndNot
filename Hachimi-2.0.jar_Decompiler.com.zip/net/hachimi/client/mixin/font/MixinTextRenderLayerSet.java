package net.hachimi.client.mixin.font;

import net.hachimi.client.api.render.layers.RenderLayersClient;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_8538;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_8538.class})
public class MixinTextRenderLayerSet {
   @Inject(
      method = {"of"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void hookOf(class_2960 textureId, CallbackInfoReturnable<class_8538> cir) {
      cir.cancel();
      cir.setReturnValue(new class_8538((class_1921)RenderLayersClient.TEXT.apply(textureId), (class_1921)RenderLayersClient.TEXT_SEE_THROUGH.apply(textureId), (class_1921)RenderLayersClient.TEXT_POLYGON_OFFSET.apply(textureId)));
   }

   @Inject(
      method = {"ofIntensity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void hookOfIntensity(class_2960 textureId, CallbackInfoReturnable<class_8538> cir) {
      cir.cancel();
      cir.setReturnValue(new class_8538((class_1921)RenderLayersClient.TEXT_INTENSITY.apply(textureId), (class_1921)RenderLayersClient.TEXT_INTENSITY_SEE_THROUGH.apply(textureId), (class_1921)RenderLayersClient.TEXT_INTENSITY_POLYGON_OFFSET.apply(textureId)));
   }
}
