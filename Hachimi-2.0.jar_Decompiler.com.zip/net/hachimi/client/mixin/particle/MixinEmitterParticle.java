package net.hachimi.client.mixin.particle;

import net.hachimi.client.impl.event.particle.EmitParticleEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1297;
import net.minecraft.class_2394;
import net.minecraft.class_733;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_733.class})
public abstract class MixinEmitterParticle extends MixinParticle implements Globals {
   @Shadow
   @Final
   private class_2394 field_3893;
   @Shadow
   @Final
   private class_1297 field_3894;
   @Shadow
   private int field_3896;
   @Mutable
   @Shadow
   @Final
   private int field_3895;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onTick(CallbackInfo ci) {
      EmitParticleEvent emitParticleEvent = new EmitParticleEvent(this.field_3893, 16, 30);
      EventBus.INSTANCE.dispatch(emitParticleEvent);
      if (emitParticleEvent.isCanceled()) {
         ci.cancel();
         this.field_3895 = emitParticleEvent.getParticleTime();

         for(int i = 0; i < emitParticleEvent.getParticleCount(); ++i) {
            double d = (double)(RANDOM.nextFloat() * 2.0F - 1.0F);
            double f;
            double e;
            if (!(d * d + (e = (double)(RANDOM.nextFloat() * 2.0F - 1.0F)) * e + (f = (double)(RANDOM.nextFloat() * 2.0F - 1.0F)) * f > (double)1.0F)) {
               double g = this.field_3894.method_23316(d / (double)4.0F);
               double h = this.field_3894.method_23323((double)0.5F + e / (double)4.0F);
               double j = this.field_3894.method_23324(f / (double)4.0F);
               mc.field_1687.method_8466(this.field_3893, false, g, h, j, d, e + 0.2, f);
            }
         }

         ++this.field_3896;
         if (this.field_3896 >= this.field_3895) {
            this.method_3085();
         }
      }

   }
}
