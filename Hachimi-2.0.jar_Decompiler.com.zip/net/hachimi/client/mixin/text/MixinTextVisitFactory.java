package net.hachimi.client.mixin.text;

import net.hachimi.client.impl.event.ClientColorEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_124;
import net.minecraft.class_2583;
import net.minecraft.class_5223;
import net.minecraft.class_5224;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(
   value = {class_5223.class},
   priority = -1000
)
public abstract class MixinTextVisitFactory implements Globals {
   private static final Logger TRACER = LogManager.getLogger("Hachimi-Tracer");

   @Shadow
   private static boolean method_27477(class_2583 style, class_5224 visitor, int index, char c) {
      return false;
   }

   @Inject(
      method = {"visitFormatted(Ljava/lang/String;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void debugTracer(String text, class_2583 style, class_5224 visitor, CallbackInfoReturnable<Boolean> cir) {
      if (mc == null || mc.field_1724 == null) {
         StackTraceElement[] stack = Thread.currentThread().getStackTrace();
         if (stack.length > 3) {
            TRACER.info("[Trace] Text: '{}' | Caller: {}.{}:{}", text, stack[3].getClassName(), stack[3].getMethodName(), stack[3].getLineNumber());
         }

         try {
            cir.setReturnValue(class_5223.method_27472(text, 0, style, visitor));
         } catch (Throwable var6) {
            TRACER.error("Bypass failed!");
         }
      }

   }

   @Inject(
      method = {"visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void hookHachimiCustom(String text, int startIndex, class_2583 startingStyle, class_2583 resetStyle, class_5224 visitor, CallbackInfoReturnable<Boolean> cir) {
      try {
         if (text == null || mc == null || mc.field_1724 == null) {
            return;
         }

         if (text.contains("§s") || text.contains("§g")) {
            cir.cancel();
            int len = text.length();
            class_2583 style = startingStyle;

            for(int j = startIndex; j < len; ++j) {
               char c = text.charAt(j);
               if (c == 167) {
                  if (j + 1 >= len) {
                     break;
                  }

                  char code = text.charAt(j + 1);
                  if (code == 's') {
                     ClientColorEvent event = new ClientColorEvent();
                     EventBus.INSTANCE.dispatch(event);
                     style = style.method_36139(event.getClientRgb());
                     ++j;
                  } else if (code == 'g') {
                     ClientColorEvent.Friend event = new ClientColorEvent.Friend();
                     EventBus.INSTANCE.dispatch(event);
                     style = style.method_36139(event.getClientRgb());
                     ++j;
                  } else {
                     class_124 formatting = class_124.method_544(code);
                     if (formatting != null) {
                        style = formatting == class_124.field_1070 ? resetStyle : style.method_27707(formatting);
                     }

                     ++j;
                  }
               } else if (!method_27477(style, visitor, j, c)) {
                  cir.setReturnValue(false);
                  return;
               }
            }

            cir.setReturnValue(true);
         }
      } catch (Throwable t) {
         TRACER.error("[Internal Error] Source File: {}", t.getStackTrace().length > 0 ? t.getStackTrace()[0].getFileName() : "Unknown");
      }

   }
}
