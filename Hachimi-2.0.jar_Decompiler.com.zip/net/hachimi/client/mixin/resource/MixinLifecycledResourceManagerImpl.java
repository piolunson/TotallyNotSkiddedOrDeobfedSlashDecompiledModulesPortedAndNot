package net.hachimi.client.mixin.resource;

import net.minecraft.class_6861;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_6861.class})
public final class MixinLifecycledResourceManagerImpl {
}
