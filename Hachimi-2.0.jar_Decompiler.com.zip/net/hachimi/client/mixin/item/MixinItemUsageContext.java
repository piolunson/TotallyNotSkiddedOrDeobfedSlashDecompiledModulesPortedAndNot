package net.hachimi.client.mixin.item;

import net.hachimi.client.impl.event.network.ItemDesyncEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_1838.class})
public final class MixinItemUsageContext implements Globals {
   @Inject(
      method = {"getStack"},
      at = {@At("RETURN")},
      cancellable = true
   )
   public void hookGetStack(CallbackInfoReturnable<class_1799> info) {
      ItemDesyncEvent itemDesyncEvent = new ItemDesyncEvent();
      EventBus.INSTANCE.dispatch(itemDesyncEvent);
      if (mc.field_1724 != null && ((class_1799)info.getReturnValue()).equals(mc.field_1724.method_6047()) && itemDesyncEvent.isCanceled()) {
         info.setReturnValue(itemDesyncEvent.getServerItem());
      }

   }
}
