package net.hachimi.client.mixin.network;

import net.hachimi.client.impl.event.gui.chat.ChatMessageEvent;
import net.hachimi.client.impl.event.network.GameJoinEvent;
import net.hachimi.client.impl.event.network.InventoryEvent;
import net.hachimi.client.impl.event.network.ServerRotationEvent;
import net.hachimi.client.impl.event.world.LoadChunkBlockEvent;
import net.hachimi.client.impl.event.world.LoadChunkEvent;
import net.hachimi.client.impl.imixin.IClientPlayNetworkHandler;
import net.hachimi.client.mixin.accessor.AccessorClientConnection;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2600;
import net.minecraft.class_2649;
import net.minecraft.class_2672;
import net.minecraft.class_2678;
import net.minecraft.class_2680;
import net.minecraft.class_2708;
import net.minecraft.class_2709;
import net.minecraft.class_2793;
import net.minecraft.class_2818;
import net.minecraft.class_2828;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7648;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_634.class})
public abstract class MixinClientPlayNetworkHandler implements IClientPlayNetworkHandler, Globals {
   @Shadow
   private class_638 field_3699;

   @Shadow
   public abstract class_2535 method_48296();

   @Inject(
      method = {"sendChatMessage"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookSendChatMessage(String content, CallbackInfo ci) {
      ChatMessageEvent.Server chatInputEvent = new ChatMessageEvent.Server(content);
      EventBus.INSTANCE.dispatch(chatInputEvent);
      if (chatInputEvent.isCanceled()) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"onGameJoin"},
      at = {@At("TAIL")}
   )
   private void hookOnGameJoin(class_2678 packet, CallbackInfo ci) {
      GameJoinEvent gameJoinEvent = new GameJoinEvent();
      EventBus.INSTANCE.dispatch(gameJoinEvent);
   }

   @Inject(
      method = {"onInventory"},
      at = {@At("TAIL")}
   )
   private void hookOnInventory(class_2649 packet, CallbackInfo ci) {
      InventoryEvent inventoryEvent = new InventoryEvent(packet);
      EventBus.INSTANCE.dispatch(inventoryEvent);
   }

   @Inject(
      method = {"onChunkData"},
      at = {@At("RETURN")}
   )
   private void hookOnChunkData(class_2672 packet, CallbackInfo ci) {
      class_2818 chunk = this.field_3699.method_2935().method_12126(packet.method_11523(), packet.method_11524(), false);
      int startX = chunk.method_12004().method_8326();
      int startZ = chunk.method_12004().method_8328();
      LoadChunkEvent loadChunkEvent = new LoadChunkEvent(chunk);
      EventBus.INSTANCE.dispatch(loadChunkEvent);

      for(int y = chunk.method_31607(); y < chunk.method_31605(); ++y) {
         for(int x1 = startX; x1 < startX + 16; ++x1) {
            for(int z1 = startZ; z1 < startZ + 16; ++z1) {
               class_2338 pos = new class_2338(x1, y, z1);
               class_2680 state = chunk.method_8320(pos);
               LoadChunkBlockEvent loadChunkBlockEvent = new LoadChunkBlockEvent(pos, state);
               EventBus.INSTANCE.dispatch(loadChunkBlockEvent);
            }
         }
      }

   }

   @Inject(
      method = {"onPlayerPositionLook"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPlayerPositionLook(class_2708 packet, CallbackInfo ci) {
      ServerRotationEvent serverRotationEvent = new ServerRotationEvent();
      EventBus.INSTANCE.dispatch(serverRotationEvent);
      if (serverRotationEvent.isCanceled()) {
         ci.cancel();
         class_2600.method_11074(packet, (class_634)this, mc);
         class_746 playerEntity = mc.field_1724;
         class_243 vec3d = playerEntity.method_18798();
         boolean bl = packet.method_11733().contains(class_2709.field_12400);
         boolean bl2 = packet.method_11733().contains(class_2709.field_12398);
         boolean bl3 = packet.method_11733().contains(class_2709.field_12403);
         double e;
         double d;
         if (bl) {
            d = vec3d.method_10216();
            e = playerEntity.method_23317() + packet.method_11734();
            playerEntity.field_6038 += packet.method_11734();
            playerEntity.field_6014 += packet.method_11734();
         } else {
            d = (double)0.0F;
            playerEntity.field_6038 = e = packet.method_11734();
            playerEntity.field_6014 = e;
         }

         double g;
         double f;
         if (bl2) {
            f = vec3d.method_10214();
            g = playerEntity.method_23318() + packet.method_11735();
            playerEntity.field_5971 += packet.method_11735();
            playerEntity.field_6036 += packet.method_11735();
         } else {
            f = (double)0.0F;
            playerEntity.field_5971 = g = packet.method_11735();
            playerEntity.field_6036 = g;
         }

         double i;
         double h;
         if (bl3) {
            h = vec3d.method_10215();
            i = playerEntity.method_23321() + packet.method_11738();
            playerEntity.field_5989 += packet.method_11738();
            playerEntity.field_5969 += packet.method_11738();
         } else {
            h = (double)0.0F;
            playerEntity.field_5989 = i = packet.method_11738();
            playerEntity.field_5969 = i;
         }

         float yaw = serverRotationEvent.getYaw();
         float pitch = serverRotationEvent.getPitch();
         playerEntity.method_5814(e, g, i);
         playerEntity.method_18800(d, f, h);
         this.method_48296().method_10743(new class_2793(packet.method_11737()));
         this.method_48296().method_10743(new class_2828.class_2830(playerEntity.method_23317(), playerEntity.method_23318(), playerEntity.method_23321(), Float.isNaN(yaw) ? playerEntity.method_36454() : yaw, Float.isNaN(pitch) ? playerEntity.method_36455() : pitch, false));
      }

   }

   public void sendQuietPacket(class_2596<?> packet) {
      ((AccessorClientConnection)this.method_48296()).hookSendInternal(packet, (class_7648)null, true);
   }
}
