package net.hachimi.client.mixin.network;

import com.mojang.authlib.GameProfile;
import net.hachimi.client.impl.event.network.CapesEvent;
import net.hachimi.client.impl.event.network.LoadCapeEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2960;
import net.minecraft.class_640;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_640.class})
public class MixinPlayerListEntry implements Globals {
   @Shadow
   @Final
   private GameProfile field_3741;
   @Unique
   private class_2960 capeTexture;
   @Unique
   private boolean capeTextureLoaded;

   @Inject(
      method = {"<init>(Lcom/mojang/authlib/GameProfile;Z)V"},
      at = {@At("TAIL")}
   )
   private void hookInit(GameProfile profile, boolean secureChatEnforced, CallbackInfo ci) {
      if (!this.capeTextureLoaded) {
         LoadCapeEvent loadCapeEvent = new LoadCapeEvent(profile, (identifier) -> this.capeTexture = identifier);
         EventBus.INSTANCE.dispatch(loadCapeEvent);
         this.capeTextureLoaded = true;
      }
   }

   @Inject(
      method = {"getSkinTextures"},
      at = {@At("TAIL")},
      cancellable = true
   )
   private void hookGetSkinTextures(CallbackInfoReturnable<class_8685> cir) {
      CapesEvent capesEvent = new CapesEvent(this.field_3741);
      EventBus.INSTANCE.dispatch(capesEvent);
      if (capesEvent.isCanceled()) {
         class_2960 identifier = capesEvent.getShowOptifine() ? this.capeTexture : null;
         if (capesEvent.getTexture() != null) {
            identifier = capesEvent.getTexture();
         }

         if (identifier != null) {
            class_8685 t = (class_8685)cir.getReturnValue();
            class_8685 customCapeTexture = new class_8685(t.comp_1626(), t.comp_1911(), identifier, identifier, t.comp_1629(), t.comp_1630());
            cir.setReturnValue(customCapeTexture);
         }

      }
   }
}
