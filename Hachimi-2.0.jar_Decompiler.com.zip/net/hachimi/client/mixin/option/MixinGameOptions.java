package net.hachimi.client.mixin.option;

import com.mojang.serialization.Codec;
import java.io.File;
import net.hachimi.client.impl.event.option.PerspectiveUpdateEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_5498;
import net.minecraft.class_7172;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_315.class})
public class MixinGameOptions {
   @Mutable
   @Shadow
   @Final
   private class_7172<Integer> field_1826;

   @Inject(
      method = {"<init>"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/GameOptions;load()V",
   shift = Shift.BEFORE
)}
   )
   private void hookInit(class_310 client, File optionsFile, CallbackInfo ci) {
      this.field_1826 = new class_7172("options.fov", class_7172.method_42399(), (optionText, value) -> {
         class_2561 var10000;
         switch (value) {
            case 70 -> var10000 = class_315.method_41783(optionText, class_2561.method_43471("options.fov.min"));
            case 110 -> var10000 = class_315.method_41783(optionText, class_2561.method_43471("options.fov.max"));
            default -> var10000 = class_315.method_41782(optionText, value);
         }

         return var10000;
      }, new class_7172.class_7174(30, 180), Codec.DOUBLE.xmap((value) -> (int)(value * (double)40.0F + (double)70.0F), (value) -> ((double)value - (double)70.0F) / (double)40.0F), 70, (value) -> class_310.method_1551().field_1769.method_3292());
   }

   @Inject(
      method = {"setPerspective"},
      at = {@At("HEAD")}
   )
   private void hookSetPerspective(class_5498 perspective, CallbackInfo ci) {
      PerspectiveUpdateEvent perspectiveEvent = new PerspectiveUpdateEvent(perspective);
      EventBus.INSTANCE.dispatch(perspectiveEvent);
   }
}
