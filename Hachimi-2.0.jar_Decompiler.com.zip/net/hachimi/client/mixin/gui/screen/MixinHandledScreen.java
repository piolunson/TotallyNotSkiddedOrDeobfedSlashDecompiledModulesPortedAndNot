package net.hachimi.client.mixin.gui.screen;

import net.hachimi.client.impl.event.gui.RenderTooltipEvent;
import net.hachimi.client.impl.event.gui.screen.MouseDraggedEvent;
import net.hachimi.client.impl.module.misc.ChestStealerModule;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_465.class})
public abstract class MixinHandledScreen {
   @Shadow
   protected @Nullable class_1735 field_2787;
   @Shadow
   private boolean field_2783;
   @Shadow
   protected int field_2776;
   @Shadow
   protected int field_2800;

   @Shadow
   protected abstract @Nullable class_1735 method_2386(double var1, double var3);

   @Shadow
   protected abstract void method_2383(class_1735 var1, int var2, int var3, class_1713 var4);

   @Inject(
      method = {"drawMouseoverTooltip"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookDrawMouseoverTooltip(class_332 context, int x, int y, CallbackInfo ci) {
      if (this.field_2787 != null) {
         RenderTooltipEvent renderTooltipEvent = new RenderTooltipEvent(context, this.field_2787.method_7677(), x, y);
         EventBus.INSTANCE.dispatch(renderTooltipEvent);
         if (renderTooltipEvent.isCanceled()) {
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"mouseDragged"},
      at = {@At("TAIL")}
   )
   private void hookMouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY, CallbackInfoReturnable<Boolean> cir) {
      MouseDraggedEvent mouseDraggedEvent = new MouseDraggedEvent();
      EventBus.INSTANCE.dispatch(mouseDraggedEvent);
      if (button == 0 && !this.field_2783 && mouseDraggedEvent.isCanceled()) {
         class_1735 slot = this.method_2386(mouseX, mouseY);
         if (slot != null && slot.method_7681() && class_437.method_25442()) {
            this.method_2383(slot, slot.field_7874, button, class_1713.field_7794);
         }

      }
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   private void hookRenderTransferAnimations(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      if (!ChestStealerModule.ANIMATIONS.isEmpty()) {
         for(ChestStealerModule.TransferAnimation anim : ChestStealerModule.ANIMATIONS) {
            if (anim.isDone()) {
               ChestStealerModule.ANIMATIONS.remove(anim);
            } else {
               float t = Math.max(0.0F, Math.min(1.0F, anim.progress()));
               float eased = 1.0F - (1.0F - t) * (1.0F - t);
               int drawX = this.field_2776 + Math.round((float)anim.fromX + (float)(anim.toX - anim.fromX) * eased);
               int drawY = this.field_2800 + Math.round((float)anim.fromY + (float)(anim.toY - anim.fromY) * eased);
               class_1799 stack = anim.stack;
               if (!stack.method_7960()) {
                  context.method_51427(stack, drawX, drawY);
               }
            }
         }

      }
   }
}
