package net.hachimi.client.mixin.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import java.io.InputStream;
import java.util.Objects;
import net.hachimi.client.Hachimi;
import net.hachimi.client.api.render.satin.ManagedShaderEffect;
import net.hachimi.client.impl.gui.account.AccountSelectorScreen;
import net.hachimi.client.init.Managers;
import net.hachimi.client.util.render.TextureUtil;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_4189;
import net.minecraft.class_426;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_4399;
import net.minecraft.class_442;
import net.minecraft.class_7077;
import net.minecraft.class_7919;
import net.minecraft.class_8082;
import net.minecraft.class_8219;
import net.minecraft.class_8519;
import net.minecraft.class_8662;
import net.minecraft.class_1011.class_1012;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_442.class})
public abstract class MixinTitleScreen extends class_437 {
   @Shadow
   private @Nullable class_8519 field_2586;
   @Shadow
   @Final
   public static class_2561 field_32271;
   @Shadow
   private @Nullable class_4399 field_2592;
   @Shadow
   private long field_17772;
   @Shadow
   @Final
   private boolean field_18222;
   @Unique
   private static final class_2960 AURORA_BG_ID = class_2960.method_60655("hachimiclient", "textures/background.png");
   @Unique
   private static boolean bgRegistered = false;
   @Unique
   private static float auroraTime = 0.0F;
   @Unique
   private static boolean shadersEnsured = false;
   @Unique
   private static boolean auroraErrorLogged = false;
   @Unique
   private static boolean bgTextureErrorLogged = false;
   @Unique
   private static final class_2960 TITLE_LOGO_ID = class_2960.method_60655("hachimi", "title_logo");
   @Unique
   private static final class_2960 BLANK_ID = class_2960.method_60655("hachimi", "blank");
   @Unique
   private static boolean titleLogoRegistered = false;
   @Unique
   private static boolean blankRegistered = false;

   @Shadow
   protected abstract void method_2251(int var1, int var2);

   @Shadow
   protected abstract void method_2249(int var1, int var2);

   @Shadow
   protected abstract boolean method_2253();

   @Unique
   private void drawAuroraBackground(class_332 context) {
      if (!shadersEnsured) {
         Managers.SHADER.reloadShaders();
         shadersEnsured = true;
      }

      ManagedShaderEffect menuEffect = Managers.SHADER.getMenuShaderEffect();
      if (menuEffect != null) {
         try {
            float w = (float)this.field_22787.method_22683().method_4486();
            float h = (float)this.field_22787.method_22683().method_4502();
            float mouseX = (float)(this.field_22787.field_1729.method_1603() / (double)this.field_22787.method_22683().method_4480());
            float mouseY = (float)(this.field_22787.field_1729.method_1604() / (double)this.field_22787.method_22683().method_4507());
            menuEffect.setUniformValue("resolution", w, h);
            menuEffect.setUniformValue("mouse", mouseX, mouseY);
            menuEffect.setUniformValue("time", auroraTime);
            menuEffect.render(0.0F);
            auroraTime += 0.016F;
            return;
         } catch (Exception e) {
            if (!auroraErrorLogged) {
               Hachimi.error("Failed to render aurora menu shader, falling back to static background: {}", e.toString());
               auroraErrorLogged = true;
            }
         }
      }

      try {
         int w = context.method_51421();
         int h = context.method_51443();
         context.method_25290(AURORA_BG_ID, 0, 0, 0.0F, 0.0F, w, h, w, h);
      } catch (Exception e) {
         if (!bgTextureErrorLogged) {
            Hachimi.error("Failed to draw fallback background texture {}: {}", AURORA_BG_ID, e.toString());
            bgTextureErrorLogged = true;
         }
      }

   }

   public MixinTitleScreen(class_2561 title) {
      super(title);
   }

   @Inject(
      method = {"render"},
      at = {@At("TAIL")}
   )
   public void hookRender(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
      float f = this.field_18222 ? (float)(class_156.method_658() - this.field_17772) / 1000.0F : 1.0F;
      float g = this.field_18222 ? class_3532.method_15363(f - 1.0F, 0.0F, 1.0F) : 1.0F;
      int i = class_3532.method_15386(g * 255.0F) << 24;
      if ((i & -67108864) != 0) {
         class_327 var10001 = this.field_22787.field_1772;
         String var10002 = String.format("%s %s", "Hachimi", "2.0");
         int var10004 = this.field_22790;
         Objects.requireNonNull(this.field_22787.field_1772);
         context.method_25303(var10001, var10002, 2, var10004 - 9 * 2 - 2, 16777215 | i);
         this.renderHachimiLogo(context);
      }
   }

   @Unique
   private void renderHachimiLogo(class_332 context) {
      if (!titleLogoRegistered) {
         try {
            InputStream stream = MixinTitleScreen.class.getResourceAsStream("/assets/hachimiclient/textures/purple.png");
            if (stream != null) {
               class_1011 img = class_1011.method_4309(stream);
               class_1043 tex = new class_1043(img);
               this.field_22787.method_1531().method_4616(TITLE_LOGO_ID, tex);
               stream.close();
            }
         } catch (Exception var8) {
         }

         titleLogoRegistered = true;
      }

      float aspect = 2.7526042F;
      int logoW = (int)class_3532.method_15363((float)this.field_22789 * 0.3F, 140.0F, 260.0F);
      int logoH = (int)((float)logoW / aspect);
      int logoX = (this.field_22789 - logoW) / 2;
      int buttonTopY = this.field_22790 / 4 + 48;
      int logoY = buttonTopY - logoH - 8;
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
      TextureUtil.drawScaled(context, TITLE_LOGO_ID, logoX, logoY, logoW, logoH);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   @Inject(
      method = {"render"},
      at = {@At("HEAD")}
   )
   public void hookRenderHead(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo info) {
      this.drawAuroraBackground(context);
   }

   @ModifyArg(
      method = {"render"},
      require = 0,
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIIIFFII)V"
),
      index = 0
   )
   private class_2960 hideVanillaLogoNew(class_2960 id) {
      return this.shouldHide(id) ? this.getBlankTexture() : id;
   }

   @ModifyArg(
      method = {"render"},
      require = 0,
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIIIIIII)V"
),
      index = 0
   )
   private class_2960 hideVanillaLogo(class_2960 id) {
      return this.shouldHide(id) ? this.getBlankTexture() : id;
   }

   @ModifyArg(
      method = {"render"},
      require = 0,
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/DrawContext;drawTexture(Lnet/minecraft/util/Identifier;IIIFFIIII)V"
),
      index = 0
   )
   private class_2960 hideVanillaLogoAlt(class_2960 id) {
      return this.shouldHide(id) ? this.getBlankTexture() : id;
   }

   @Unique
   private boolean shouldHide(class_2960 id) {
      String path = id.method_12832();
      return path.contains("title/minecraft") || path.contains("title/edition") || path.contains("title/minceraft");
   }

   @Unique
   private class_2960 getBlankTexture() {
      if (!blankRegistered) {
         try {
            class_1011 img = new class_1011(class_1012.field_4997, 1, 1, true);
            img.method_4305(0, 0, 0);
            this.field_22787.method_1531().method_4616(BLANK_ID, new class_1043(img));
         } catch (Exception var2) {
         }

         blankRegistered = true;
      }

      return BLANK_ID;
   }

   @Inject(
      method = {"init"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookInit(CallbackInfo ci) {
      ci.cancel();
      if (this.field_2586 == null) {
         this.field_2586 = this.field_22787.method_18095().method_18174();
      }

      int i = this.field_22793.method_27525(field_32271);
      int j = this.field_22789 - i - 2;
      int k = 24;
      int l = this.field_22790 / 4 + 48;
      if (this.field_22787.method_1530()) {
         this.method_2251(l, 24);
      } else {
         this.method_2249(l, 24);
      }

      class_8662 textIconButtonWidget = (class_8662)this.method_37063(class_8082.method_48592(20, (button) -> this.field_22787.method_1507(new class_426(this, this.field_22787.field_1690, this.field_22787.method_1526())), true));
      textIconButtonWidget.method_48229(this.field_22789 / 2 - 124, l + 72 + 24);
      this.method_37063(class_4185.method_46430(class_2561.method_43471("menu.options"), (button) -> this.field_22787.method_1507(new class_429(this, this.field_22787.field_1690))).method_46434(this.field_22789 / 2 - 100, l + 72 + 24, 98, 20).method_46431());
      this.method_37063(class_4185.method_46430(class_2561.method_43471("menu.quit"), (button) -> this.field_22787.method_1592()).method_46434(this.field_22789 / 2 + 2, l + 72 + 24, 98, 20).method_46431());
      class_8662 textIconButtonWidget2 = (class_8662)this.method_37063(class_8082.method_48594(20, (button) -> this.field_22787.method_1507(new class_4189(this, this.field_22787.field_1690)), true));
      textIconButtonWidget2.method_48229(this.field_22789 / 2 + 104, l + 72 + 24);
      this.method_37063(new class_7077(j, this.field_22790 - 10, i, 10, field_32271, (button) -> this.field_22787.method_1507(new class_8219(this)), this.field_22793));
      if (this.field_2592 == null) {
         this.field_2592 = new class_4399();
      }

      if (this.method_2253()) {
         this.field_2592.method_25423(this.field_22787, this.field_22789, this.field_22790);
      }

   }

   @Inject(
      method = {"initWidgetsNormal"},
      at = {@At(
   target = "Lnet/minecraft/client/gui/screen/TitleScreen;addDrawableChild(Lnet/minecraft/client/gui/Element;)Lnet/minecraft/client/gui/Element;",
   value = "INVOKE",
   shift = Shift.AFTER,
   ordinal = 2
)}
   )
   public void hookInit(int y, int spacingY, CallbackInfo ci) {
      class_4185 widget = class_4185.method_46430(class_2561.method_30163("Account Manager"), (action) -> this.field_22787.method_1507(new AccountSelectorScreen(this))).method_46434(this.field_22789 / 2 - 100, y + spacingY * 3, 200, 20).method_46436(class_7919.method_47407(class_2561.method_30163("Allows you to switch your in-game account"))).method_46431();
      widget.field_22763 = true;
      this.method_37063(widget);
   }
}
