package net.hachimi.client.mixin.gui.screen;

import net.hachimi.client.util.Globals;
import net.minecraft.class_419;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_419.class})
public abstract class MixinDisconnectedScreen extends MixinScreen implements Globals {
}
