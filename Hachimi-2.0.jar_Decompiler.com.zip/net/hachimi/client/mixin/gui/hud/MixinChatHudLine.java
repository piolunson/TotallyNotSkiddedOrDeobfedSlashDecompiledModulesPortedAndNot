package net.hachimi.client.mixin.gui.hud;

import net.hachimi.client.impl.imixin.IChatHudLine;
import net.hachimi.client.util.Globals;
import net.minecraft.class_303;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin({class_303.class})
public abstract class MixinChatHudLine implements IChatHudLine, Globals {
   @Unique
   private int id;

   public int getId() {
      return this.id;
   }

   public void setId(int id) {
      this.id = id;
   }
}
