package net.hachimi.client.mixin.gui.hud;

import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalIntRef;
import java.util.Comparator;
import java.util.List;
import net.hachimi.client.impl.event.gui.hud.PlayerListColumnsEvent;
import net.hachimi.client.impl.event.gui.hud.PlayerListEvent;
import net.hachimi.client.impl.event.gui.hud.PlayerListIconEvent;
import net.hachimi.client.impl.event.gui.hud.PlayerListNameEvent;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({class_355.class})
public abstract class MixinPlayerListHud {
   @Shadow
   @Final
   private static Comparator<class_640> field_2156;
   @Shadow
   @Final
   private class_310 field_2155;

   @Shadow
   protected abstract List<class_640> method_48213();

   @Shadow
   protected abstract class_2561 method_27538(class_640 var1, class_5250 var2);

   @Inject(
      method = {"getPlayerName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookGetPlayerName(class_640 entry, CallbackInfoReturnable<class_2561> cir) {
      class_2561 text;
      if (entry.method_2971() != null) {
         text = this.method_27538(entry, entry.method_2971().method_27661());
      } else {
         text = this.method_27538(entry, class_268.method_1142(entry.method_2955(), class_2561.method_43470(entry.method_2966().getName())));
      }

      PlayerListNameEvent playerListNameEvent = new PlayerListNameEvent(text, entry.method_2966().getId());
      EventBus.INSTANCE.dispatch(playerListNameEvent);
      if (playerListNameEvent.isCanceled()) {
         cir.cancel();
         cir.setReturnValue(playerListNameEvent.getPlayerName());
      }

   }

   @Redirect(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/font/TextRenderer;getWidth(Lnet/minecraft/text/StringVisitable;)I"
)
   )
   private int hookRender(class_327 instance, class_5348 text) {
      PlayerListIconEvent.Width playerListIconEvent = new PlayerListIconEvent.Width(text.getString());
      EventBus.INSTANCE.dispatch(playerListIconEvent);
      return playerListIconEvent.isCanceled() ? instance.method_27525(text) + 12 : instance.method_27525(text);
   }

   @Redirect(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/Text;III)I"
)
   )
   private int hookRender(class_332 instance, class_327 textRenderer, class_2561 text, int x, int y, int color) {
      PlayerListIconEvent.Render playerListIconEvent = new PlayerListIconEvent.Render(text, instance, textRenderer, (double)x, (double)y, color);
      EventBus.INSTANCE.dispatch(playerListIconEvent);
      int x1 = playerListIconEvent.isCanceled() ? x + 12 : x;
      instance.method_27535(textRenderer, text, x1, y, color);
      return x1;
   }

   @Inject(
      method = {"collectPlayerEntries"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void hookCollectPlayerEntries(CallbackInfoReturnable<List<class_640>> cir) {
      PlayerListEvent playerListEvent = new PlayerListEvent();
      EventBus.INSTANCE.dispatch(playerListEvent);
      if (playerListEvent.isCanceled()) {
         cir.cancel();
         cir.setReturnValue(this.field_2155.field_1724.field_3944.method_45732().stream().sorted(field_2156).limit((long)playerListEvent.getSize()).toList());
      }

   }

   @Inject(
      method = {"render"},
      at = {@At(
   value = "INVOKE",
   target = "Ljava/lang/Math;min(II)I",
   shift = Shift.BEFORE
)}
   )
   private void hookRender(CallbackInfo ci, @Local(ordinal = 5) LocalIntRef o, @Local(ordinal = 6) LocalIntRef p) {
      int newP = 1;
      int newO;
      int totalPlayers = newO = this.method_48213().size();
      PlayerListColumnsEvent playerListColumsEvent = new PlayerListColumnsEvent();
      EventBus.INSTANCE.dispatch(playerListColumsEvent);
      if (playerListColumsEvent.isCanceled()) {
         while(newO > playerListColumsEvent.getTabHeight()) {
            ++newP;
            newO = (totalPlayers + newP - 1) / newP;
         }

         o.set(newO);
         p.set(newP);
      }

   }
}
