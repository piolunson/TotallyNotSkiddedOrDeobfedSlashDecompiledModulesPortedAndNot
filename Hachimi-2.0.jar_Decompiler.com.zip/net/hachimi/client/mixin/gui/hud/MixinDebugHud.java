package net.hachimi.client.mixin.gui.hud;

import java.util.List;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_340.class})
public abstract class MixinDebugHud {
   @Shadow
   protected abstract List<String> method_1835();

   @Redirect(
      method = {"drawLeftText"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/hud/DebugHud;getLeftText()Ljava/util/List;"
)
   )
   private List<String> redirectRightTextEarly(class_340 instance) {
      List<String> list = this.method_1835();
      String modName = String.format("%s %s (%s%s%s)", "Hachimi", "2.0", "\"release\"", !"\"release\"".equals("dev") ? "-2.0" : "", !"null".equals("null") ? "-null" : "");
      list.add(1, modName);
      return list;
   }
}
