package net.hachimi.client.mixin.gui.hud;

import net.hachimi.client.impl.event.gui.hud.ChatLineEvent;
import net.hachimi.client.impl.imixin.IChatHudLineVisible;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.minecraft.class_303;
import net.minecraft.class_5481;
import net.minecraft.class_7591;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_303.class_7590.class})
public class MixinChatHudLineVisible implements IChatHudLineVisible, Globals {
   @Unique
   private int id;

   @Inject(
      method = {"<init>"},
      at = {@At("RETURN")}
   )
   private void hookInit(int i, class_5481 orderedText, class_7591 messageIndicator, boolean bl, CallbackInfo ci) {
      ChatLineEvent chatLineEvent = new ChatLineEvent((class_303.class_7590)this, (double)(-mc.field_1772.method_30880(orderedText)));
      EventBus.INSTANCE.dispatch(chatLineEvent);
   }

   public int getId() {
      return this.id;
   }

   public void setId(int id) {
      this.id = id;
   }
}
