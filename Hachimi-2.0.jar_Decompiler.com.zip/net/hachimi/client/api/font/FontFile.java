package net.hachimi.client.api.font;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import net.hachimi.client.api.file.ConfigFile;
import net.hachimi.client.init.Fonts;

public class FontFile extends ConfigFile {
   public FontFile(Path dir) {
      super(dir, "fonts");
   }

   public void save() {
      try {
         Path filepath = this.getFilepath();
         if (!Files.exists(filepath, new LinkOption[0])) {
            Files.createFile(filepath);
         }

         JsonObject jsonObject = new JsonObject();
         jsonObject.addProperty("fontpath", Fonts.FONT_FILE_PATH);
         this.write(this.getFilepath(), this.serialize(jsonObject));
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   public void load() {
      try {
         Path filepath = this.getFilepath();
         if (Files.exists(filepath, new LinkOption[0])) {
            String content = this.read(filepath);
            JsonObject object = this.parseObject(content);
            Fonts.FONT_FILE_PATH = object.get("fontpath").getAsString();
         }
      } catch (IOException e) {
         e.printStackTrace();
      }

   }
}
