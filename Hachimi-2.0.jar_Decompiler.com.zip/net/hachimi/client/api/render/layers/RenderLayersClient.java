package net.hachimi.client.api.render.layers;

import java.util.function.BiFunction;
import java.util.function.Function;
import net.hachimi.client.init.Managers;
import net.hachimi.client.mixin.accessor.AccessorRenderPhase;
import net.hachimi.client.util.Globals;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import net.minecraft.class_918;
import net.minecraft.class_1921.class_4688;
import net.minecraft.class_293.class_5596;
import org.lwjgl.opengl.GL11;

public class RenderLayersClient implements Globals {
   public static final class_2960 SHULKER_BOXES_ATLAS_TEXTURE = class_2960.method_60654("textures/atlas/shulker_boxes.png");
   public static final class_2960 CHEST_ATLAS_TEXTURE = class_2960.method_60654("textures/atlas/chest.png");
   public static final class_1921 GLINT;
   public static final Function<class_2960, class_1921> ENTITY_NO_OUTLINE;
   public static final BiFunction<class_2960, Boolean, class_1921> ENTITY_TRANSLUCENT;
   public static final Function<class_2960, class_1921> ENTITY_SOLID;
   public static final Function<class_2960, class_1921> ITEM_ENTITY_TRANSLUCENT_CULL_2;
   public static final Function<class_2960, class_1921> ENTITY_TRANSLUCENT_CULL;
   public static final Function<class_2960, class_1921> ENTITY_CUTOUT;
   public static final Function<class_2960, class_1921> ENTITY_CUTOUT_NO_CULL;
   public static final BiFunction<class_2960, Boolean, class_1921> ENTITY_CUTOUT_NO_CULL_Z_OFFSET;
   public static final Function<class_2960, class_1921> TEXT;
   public static final class_1921 TEXT_BACKGROUND;
   public static final Function<class_2960, class_1921> TEXT_INTENSITY;
   public static final Function<class_2960, class_1921> TEXT_POLYGON_OFFSET;
   public static final Function<class_2960, class_1921> TEXT_INTENSITY_POLYGON_OFFSET;
   public static final Function<class_2960, class_1921> TEXT_SEE_THROUGH;
   public static final class_1921 TEXT_BACKGROUND_SEE_THROUGH;
   public static final Function<class_2960, class_1921> TEXT_INTENSITY_SEE_THROUGH;

   static {
      GLINT = class_1921.method_24048("glint", class_290.field_1585, class_5596.field_27382, 256, class_4688.method_23598().method_34578(class_4668.field_29422).method_34577(new class_4668.class_4683(class_918.field_43087, true, false)).method_23616(class_4668.field_21350).method_23603(class_4668.field_21345).method_23604(new DepthTest()).method_23615(class_4668.field_21368).method_23614(class_4668.field_21381).method_23617(false));
      ENTITY_NO_OUTLINE = class_156.method_34866((texture) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29411).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23603(class_1921.field_21345).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23616(class_1921.field_21350).method_23617(false);
         return class_1921.method_24049("entity_no_outline", class_290.field_1580, class_5596.field_27382, 1536, false, true, multiPhaseParameters);
      });
      ENTITY_TRANSLUCENT = class_156.method_34865((texture, affectsOutline) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29407).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23603(class_1921.field_21345).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23617(affectsOutline);
         return class_1921.method_24049("entity_translucent", class_290.field_1580, class_5596.field_27382, 1536, true, true, multiPhaseParameters);
      });
      ENTITY_SOLID = class_156.method_34866((texture) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29450).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21364).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23617(true);
         return class_1921.method_24049("entity_solid", class_290.field_1580, class_5596.field_27382, 1536, true, false, multiPhaseParameters);
      });
      ITEM_ENTITY_TRANSLUCENT_CULL_2 = class_156.method_34866((texture) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29405).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23610(class_1921.field_25643).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23616(class_4668.field_21349).method_23617(true);
         return class_1921.method_24049("item_entity_translucent_cull", class_290.field_1580, class_5596.field_27382, 1536, true, true, multiPhaseParameters);
      });
      ENTITY_TRANSLUCENT_CULL = class_156.method_34866((texture) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29406).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23617(true);
         return class_1921.method_24049("entity_translucent_cull", class_290.field_1580, class_5596.field_27382, 1536, true, true, multiPhaseParameters);
      });
      ENTITY_CUTOUT = class_156.method_34866((texture) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29451).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21364).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23617(true);
         return class_1921.method_24049("entity_cutout", class_290.field_1580, class_5596.field_27382, 1536, true, false, multiPhaseParameters);
      });
      ENTITY_CUTOUT_NO_CULL = class_156.method_34866((texture) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29452).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21364).method_23603(class_1921.field_21345).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23617(true);
         return class_1921.method_24049("entity_cutout_no_cull", class_290.field_1580, class_5596.field_27382, 1536, true, false, multiPhaseParameters);
      });
      ENTITY_CUTOUT_NO_CULL_Z_OFFSET = class_156.method_34865((texture, affectsOutline) -> {
         class_1921.class_4688 multiPhaseParameters = class_4688.method_23598().method_34578(class_1921.field_29404).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21364).method_23603(class_1921.field_21345).method_23608(new Lightmap()).method_23611(class_1921.field_21385).method_23607(class_1921.field_22241).method_23617(affectsOutline);
         return class_1921.method_24049("entity_cutout_no_cull_z_offset", class_290.field_1580, class_5596.field_27382, 1536, true, false, multiPhaseParameters);
      });
      TEXT = class_156.method_34866((texture) -> class_1921.method_24049("text", class_290.field_20888, class_5596.field_27382, 786432, false, true, class_4688.method_23598().method_34578(class_1921.field_29427).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23617(false)));
      TEXT_BACKGROUND = class_1921.method_24049("text_background", class_290.field_21468, class_5596.field_27382, 1536, false, true, class_4688.method_23598().method_34578(class_1921.field_42517).method_34577(class_1921.field_21378).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23617(false));
      TEXT_INTENSITY = class_156.method_34866((texture) -> class_1921.method_24049("text_intensity", class_290.field_20888, class_5596.field_27382, 786432, false, true, class_4688.method_23598().method_34578(class_1921.field_33628).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23617(false)));
      TEXT_POLYGON_OFFSET = class_156.method_34866((texture) -> class_1921.method_24049("text_polygon_offset", class_290.field_20888, class_5596.field_27382, 1536, false, true, class_4688.method_23598().method_34578(class_1921.field_29427).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23607(class_1921.field_21353).method_23617(false)));
      TEXT_INTENSITY_POLYGON_OFFSET = class_156.method_34866((texture) -> class_1921.method_24049("text_intensity_polygon_offset", class_290.field_20888, class_5596.field_27382, 1536, false, true, class_4688.method_23598().method_34578(class_1921.field_33628).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23607(class_1921.field_21353).method_23617(false)));
      TEXT_SEE_THROUGH = class_156.method_34866((texture) -> class_1921.method_24049("text_see_through", class_290.field_20888, class_5596.field_27382, 1536, false, true, class_4688.method_23598().method_34578(class_1921.field_29428).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23604(class_1921.field_21346).method_23616(class_1921.field_21350).method_23617(false)));
      TEXT_BACKGROUND_SEE_THROUGH = class_1921.method_24049("text_background_see_through", class_290.field_21468, class_5596.field_27382, 1536, false, true, class_4688.method_23598().method_34578(class_1921.field_42518).method_34577(class_1921.field_21378).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23604(class_1921.field_21346).method_23616(class_1921.field_21350).method_23617(false));
      TEXT_INTENSITY_SEE_THROUGH = class_156.method_34866((texture) -> class_1921.method_24049("text_intensity_see_through", class_290.field_20888, class_5596.field_27382, 1536, false, true, class_4688.method_23598().method_34578(class_1921.field_33629).method_34577(new class_4668.class_4683(texture, false, false)).method_23615(class_1921.field_21370).method_23608(new Lightmap()).method_23604(class_1921.field_21346).method_23616(class_1921.field_21350).method_23617(false)));
   }

   protected static class DepthTest extends class_4668.class_4672 {
      public DepthTest() {
         super("depth_test", 519);
      }

      public void method_23516() {
         GL11.glEnable(2929);
         GL11.glDepthMask(true);
         GL11.glDepthFunc(514);
      }

      public void method_23518() {
         GL11.glDisable(2929);
         GL11.glDepthMask(false);
         GL11.glDepthFunc(515);
         GL11.glDepthFunc(519);
      }
   }

   protected static class Lightmap extends class_4668.class_4676 {
      public Lightmap() {
         super(false);
         ((AccessorRenderPhase)this).hookSetBeginAction(() -> Managers.LIGHT_MAP.enable());
         ((AccessorRenderPhase)this).hookSetEndAction(() -> Managers.LIGHT_MAP.disable());
      }
   }
}
