package net.hachimi.client.api.render.layers;

import com.mojang.blaze3d.systems.RenderSystem;
import net.hachimi.client.impl.event.render.LightmapInitEvent;
import net.hachimi.client.impl.event.render.LightmapTickEvent;
import net.hachimi.client.impl.event.render.LightmapUpdateEvent;
import net.hachimi.client.util.Globals;
import net.hachimi.eventbus.EventBus;
import net.hachimi.eventbus.annotation.EventListener;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2874;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_638;
import net.minecraft.class_757;
import org.joml.Vector3f;

public class LightmapManager implements AutoCloseable, Globals {
   private class_1043 texture;
   private class_1011 image;
   private class_2960 textureIdentifier;
   private boolean dirty;
   private float flickerIntensity;
   private class_757 renderer;

   public LightmapManager() {
      EventBus.INSTANCE.subscribe(this);
   }

   @EventListener
   public void onLightmapInit(LightmapInitEvent event) {
      this.renderer = mc.field_1773;
      this.texture = new class_1043(16, 16, false);
      this.textureIdentifier = mc.method_1531().method_4617("hachimi_light_map", this.texture);
      this.image = this.texture.method_4525();

      for(int i = 0; i < 16; ++i) {
         for(int j = 0; j < 16; ++j) {
            this.image.method_4305(j, i, -1);
         }
      }

      this.texture.method_4524();
   }

   @EventListener
   public void onLightmapTick(LightmapTickEvent event) {
      this.flickerIntensity += (float)((Math.random() - Math.random()) * Math.random() * Math.random() * 0.1);
      this.flickerIntensity *= 0.9F;
      this.dirty = true;
   }

   @EventListener
   public void onLightmapUpdate(LightmapUpdateEvent event) {
      if (this.renderer != null && this.texture != null && this.image != null) {
         if (this.dirty) {
            this.dirty = false;
            class_638 clientWorld = mc.field_1687;
            if (clientWorld != null) {
               float f = clientWorld.method_23783(1.0F);
               float g;
               if (clientWorld.method_23789() > 0) {
                  g = 1.0F;
               } else {
                  g = f * 0.95F + 0.05F;
               }

               float h = ((Double)mc.field_1690.method_42472().method_41753()).floatValue();
               float i = this.getDarknessFactor(event.getTickDelta()) * h;
               float j = this.getDarkness(mc.field_1724, i, event.getTickDelta()) * h;
               float k = mc.field_1724.method_3140();
               float l;
               if (mc.field_1724.method_6059(class_1294.field_5925)) {
                  l = class_757.method_3174(mc.field_1724, event.getTickDelta());
               } else if (k > 0.0F && mc.field_1724.method_6059(class_1294.field_5927)) {
                  l = k;
               } else {
                  l = 0.0F;
               }

               Vector3f vector3f = (new Vector3f(f, f, 1.0F)).lerp(new Vector3f(1.0F, 1.0F, 1.0F), 0.35F);
               float m = this.flickerIntensity + 1.5F;
               Vector3f vector3f2 = new Vector3f();

               for(int n = 0; n < 16; ++n) {
                  for(int o = 0; o < 16; ++o) {
                     float p = getBrightness(clientWorld.method_8597(), n) * g;
                     float q = getBrightness(clientWorld.method_8597(), o) * m;
                     float s = q * ((q * 0.6F + 0.4F) * 0.6F + 0.4F);
                     float t = q * (q * q * 0.6F + 0.4F);
                     vector3f2.set(q, s, t);
                     boolean bl = clientWorld.method_28103().method_28114();
                     if (bl) {
                        vector3f2.lerp(new Vector3f(0.99F, 1.12F, 1.0F), 0.25F);
                        clamp(vector3f2);
                     } else {
                        Vector3f vector3f3 = (new Vector3f(vector3f)).mul(p);
                        vector3f2.add(vector3f3);
                        vector3f2.lerp(new Vector3f(0.75F, 0.75F, 0.75F), 0.04F);
                        if (this.renderer.method_3195(event.getTickDelta()) > 0.0F) {
                           float u = this.renderer.method_3195(event.getTickDelta());
                           Vector3f vector3f4 = (new Vector3f(vector3f2)).mul(0.7F, 0.6F, 0.6F);
                           vector3f2.lerp(vector3f4, u);
                        }
                     }

                     if (l > 0.0F) {
                        float v = Math.max(vector3f2.x(), Math.max(vector3f2.y(), vector3f2.z()));
                        if (v < 1.0F) {
                           float u = 1.0F / v;
                           Vector3f vector3f4 = (new Vector3f(vector3f2)).mul(u);
                           vector3f2.lerp(vector3f4, l);
                        }
                     }

                     if (!bl) {
                        if (j > 0.0F) {
                           vector3f2.add(-j, -j, -j);
                        }

                        clamp(vector3f2);
                     }

                     float v = ((Double)mc.field_1690.method_42473().method_41753()).floatValue();
                     Vector3f vector3f5 = new Vector3f(this.easeOutQuart(vector3f2.x), this.easeOutQuart(vector3f2.y), this.easeOutQuart(vector3f2.z));
                     vector3f2.lerp(vector3f5, Math.max(0.0F, v - i));
                     vector3f2.lerp(new Vector3f(0.75F, 0.75F, 0.75F), 0.04F);
                     clamp(vector3f2);
                     vector3f2.mul(255.0F);
                     int x = (int)vector3f2.x();
                     int y = (int)vector3f2.y();
                     int z = (int)vector3f2.z();
                     this.image.method_4305(o, n, -16777216 | z << 16 | y << 8 | x);
                  }
               }

               this.texture.method_4524();
            }
         }

      }
   }

   public void close() {
      this.texture.close();
   }

   public void disable() {
      RenderSystem.setShaderTexture(2, 0);
   }

   public void enable() {
      if (this.textureIdentifier != null) {
         RenderSystem.setShaderTexture(2, this.textureIdentifier);
         mc.method_1531().method_22813(this.textureIdentifier);
         RenderSystem.texParameter(3553, 10241, 9729);
         RenderSystem.texParameter(3553, 10240, 9729);
      }
   }

   private float getDarknessFactor(float delta) {
      class_1293 statusEffectInstance = mc.field_1724.method_6112(class_1294.field_38092);
      return statusEffectInstance != null ? statusEffectInstance.method_55653(mc.field_1724, delta) : 0.0F;
   }

   private float getDarkness(class_1309 entity, float factor, float delta) {
      float f = 0.45F * factor;
      return Math.max(0.0F, class_3532.method_15362(((float)entity.field_6012 - delta) * (float)Math.PI * 0.025F) * f);
   }

   private static void clamp(Vector3f vec) {
      vec.set(class_3532.method_15363(vec.x, 0.0F, 1.0F), class_3532.method_15363(vec.y, 0.0F, 1.0F), class_3532.method_15363(vec.z, 0.0F, 1.0F));
   }

   private float easeOutQuart(float x) {
      float f = 1.0F - x;
      return 1.0F - f * f * f * f;
   }

   public static float getBrightness(class_2874 type, int lightLevel) {
      float f = (float)lightLevel / 15.0F;
      float g = f / (4.0F - 3.0F * f);
      return class_3532.method_16439(type.comp_656(), g, 1.0F);
   }

   public static int pack(int block, int sky) {
      return block << 4 | sky << 20;
   }
}
