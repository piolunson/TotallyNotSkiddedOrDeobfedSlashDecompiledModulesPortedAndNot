package net.hachimi.client.api.render.shader;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.hachimi.client.api.render.satin.ManagedShaderEffect;
import net.hachimi.client.api.render.satin.ShaderEffectManager;
import net.hachimi.client.impl.imixin.IPostEffectProcessor;
import net.hachimi.client.mixin.accessor.AccessorMultiPhase;
import net.hachimi.client.mixin.accessor.AccessorMultiPhaseParameters;
import net.hachimi.client.mixin.accessor.AccessorTextureBase;
import net.hachimi.client.util.Globals;
import net.minecraft.class_1921;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4618;
import net.minecraft.class_4668;
import net.minecraft.class_9799;
import net.minecraft.class_1921.class_4688;
import net.minecraft.class_1921.class_4750;
import net.minecraft.class_293.class_5596;

public class ShaderManager implements Globals {
   private final class_4618 vertexConsumerProvider = new class_4618(class_4597.method_22991(new class_9799(256)));
   private final Function<class_4668.class_5939, class_1921> layerCreator = this.memoizeTexture((texture) -> class_1921.method_24048("hachimi_overlay", class_290.field_1575, class_5596.field_27382, 1536, class_4688.method_23598().method_34578(class_4668.field_29418).method_23603(class_4668.field_21345).method_34577(texture).method_23604(class_4668.field_21346).method_23610(this.target).method_24297(class_4750.field_21854)));
   private final class_4668.class_4678 target = new class_4668.class_4678("shader_target", () -> {
   }, () -> {
   });
   private ShaderFramebuffer framebuffer;
   public ManagedShaderEffect filledShaderEffect;
   public ManagedShaderEffect gradientShaderEffect;
   public ManagedShaderEffect imageShaderEffect;
   public ManagedShaderEffect glowingShaderEffect;
   public ManagedShaderEffect rainbowShaderEffect;
   public ManagedShaderEffect bloomShaderEffect;
   public ManagedShaderEffect menuShaderEffect;
   public ManagedShaderEffect blurShaderEffect;

   public void reloadShaders() {
      if (this.framebuffer == null) {
         this.framebuffer = new ShaderFramebuffer(mc.method_1522().field_1482, mc.method_1522().field_1481);
      }

      if (this.filledShaderEffect == null) {
         this.filledShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/outline.json"));
      }

      if (this.gradientShaderEffect == null) {
         this.gradientShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/gradient.json"));
      }

      if (this.imageShaderEffect == null) {
         this.imageShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/image.json"));
      }

      if (this.glowingShaderEffect == null) {
         this.glowingShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/glowing.json"));
      }

      if (this.rainbowShaderEffect == null) {
         this.rainbowShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/rainbow.json"));
      }

      if (this.bloomShaderEffect == null) {
         this.bloomShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/bloom.json"));
      }

      if (this.menuShaderEffect == null) {
         this.menuShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/menu.json"));
      }

      if (this.blurShaderEffect == null) {
         this.blurShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/blur.json"));
      }

   }

   public void reloadShadersInternal() {
      this.framebuffer = new ShaderFramebuffer(mc.method_1522().field_1482, mc.method_1522().field_1481);
      this.filledShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/outline.json"));
      this.gradientShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/gradient.json"));
      this.imageShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/image.json"));
      this.glowingShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/glowing.json"));
      this.rainbowShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/rainbow.json"));
      this.bloomShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/bloom.json"));
      this.menuShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/menu.json"));
      this.blurShaderEffect = ShaderEffectManager.getInstance().manage(class_2960.method_60655("hachimiclient", "shaders/post/blur.json"));
   }

   public void applyShader(ManagedShaderEffect shaderEffect, Runnable setup, Runnable runnable) {
      class_276 mcFramebuffer = mc.method_1522();
      RenderSystem.assertOnRenderThreadOrInit();
      if (this.framebuffer.field_1482 != mcFramebuffer.field_1482 || this.framebuffer.field_1481 != mcFramebuffer.field_1481) {
         this.framebuffer.method_1234(mcFramebuffer.field_1482, mcFramebuffer.field_1481, false);
      }

      GlStateManager._glBindFramebuffer(36009, this.framebuffer.field_1476);
      this.framebuffer.method_1235(false);
      runnable.run();
      this.framebuffer.method_1240();
      GlStateManager._glBindFramebuffer(36009, mcFramebuffer.field_1476);
      mcFramebuffer.method_1235(false);
      class_279 effect = shaderEffect.getShaderEffect();
      if (effect != null) {
         ((IPostEffectProcessor)effect).overwriteBuffer("bufIn", this.framebuffer);
         class_276 bufOut = effect.method_1264("bufOut");
         setup.run();
         this.framebuffer.method_1230(false);
         mcFramebuffer.method_1235(false);
         RenderSystem.enableBlend();
         RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ZERO, class_4534.ONE);
         RenderSystem.backupProjectionMatrix();
         bufOut.method_22594(bufOut.field_1482, bufOut.field_1481, false);
         RenderSystem.restoreProjectionMatrix();
         RenderSystem.defaultBlendFunc();
         RenderSystem.disableBlend();
      }

   }

   public class_4597 createVertexConsumers(class_4597 parent, Color color) {
      return (layer) -> {
         class_4588 parentBuffer = parent.getBuffer(layer);
         if (layer instanceof class_1921.class_4687 && ((AccessorMultiPhaseParameters)((AccessorMultiPhase)layer).hookGetPhases()).hookGetOutlineMode() != class_4750.field_21853) {
            this.vertexConsumerProvider.method_23286(color.getRed(), color.getGreen(), color.getBlue(), 255);
            class_4588 outlineBuffer = this.vertexConsumerProvider.getBuffer((class_1921)this.layerCreator.apply(((AccessorMultiPhaseParameters)((AccessorMultiPhase)layer).hookGetPhases()).hookGetTexture()));
            return outlineBuffer != null ? outlineBuffer : parentBuffer;
         } else {
            return parentBuffer;
         }
      };
   }

   private Function<class_4668.class_5939, class_1921> memoizeTexture(final Function<class_4668.class_5939, class_1921> function) {
      return new Function<class_4668.class_5939, class_1921>() {
         private final Map<class_2960, class_1921> cache = new HashMap();

         public class_1921 apply(class_4668.class_5939 texture) {
            return (class_1921)this.cache.computeIfAbsent((class_2960)((AccessorTextureBase)texture).hookGetId().get(), (id) -> (class_1921)function.apply(texture));
         }
      };
   }

   public ManagedShaderEffect getFilledShaderEffect() {
      return this.filledShaderEffect;
   }

   public ManagedShaderEffect getGradientShaderEffect() {
      return this.gradientShaderEffect;
   }

   public ManagedShaderEffect getImageShaderEffect() {
      return this.imageShaderEffect;
   }

   public ManagedShaderEffect getGlowingShaderEffect() {
      return this.glowingShaderEffect;
   }

   public ManagedShaderEffect getRainbowShaderEffect() {
      return this.rainbowShaderEffect;
   }

   public ManagedShaderEffect getBloomShaderEffect() {
      return this.bloomShaderEffect;
   }

   public ManagedShaderEffect getMenuShaderEffect() {
      return this.menuShaderEffect;
   }

   public ManagedShaderEffect getBlurShaderEffect() {
      return this.blurShaderEffect;
   }
}
