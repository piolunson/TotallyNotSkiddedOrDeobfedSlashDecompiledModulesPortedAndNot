package net.hachimi.client.api.module;

import net.hachimi.client.api.Hideable;
import net.hachimi.client.api.config.Config;
import net.hachimi.client.api.config.setting.BooleanConfig;
import net.hachimi.client.api.config.setting.MacroConfig;
import net.hachimi.client.api.config.setting.ToggleConfig;
import net.hachimi.client.api.macro.Macro;
import net.hachimi.client.util.chat.ChatUtil;
import net.hachimi.client.util.render.animation.Animation;
import net.hachimi.client.util.render.animation.Easing;

public class ToggleModule extends Module implements Hideable {
   private final Animation animation;
   Config<Boolean> enabledConfig;
   Config<Macro> keybindingConfig;
   Config<Boolean> hiddenConfig;
   Config<Boolean> notifyConfig;

   public ToggleModule(String name, String desc, ModuleCategory category) {
      super(name, desc, category);
      this.animation = new Animation(false, 300.0F, Easing.CUBIC_IN_OUT);
      this.enabledConfig = this.register(new ToggleConfig("Enabled", "The module enabled state", false));
      this.keybindingConfig = this.register(new MacroConfig("Keybind", "The keybind to toggle the module", new Macro(this.getId(), -1, () -> this.toggle())));
      this.hiddenConfig = this.register(new BooleanConfig("Hidden", "The hidden state of the module in the arraylist", true));
      this.notifyConfig = this.register(new BooleanConfig("Notify", "Notifies you when the module is toggled in chat", true, () -> false));
      this.register(new Config[]{this.keybindingConfig, this.enabledConfig, this.hiddenConfig});
   }

   public ToggleModule(String name, String desc, ModuleCategory category, Integer keycode) {
      this(name, desc, category);
      this.keybind(keycode);
   }

   public boolean isHidden() {
      return (Boolean)this.hiddenConfig.getValue();
   }

   public void setHidden(boolean hidden) {
      this.hiddenConfig.setValue(hidden);
   }

   public void toggle() {
      if (this.isEnabled()) {
         this.disable();
      } else {
         this.enable();
      }

   }

   public void enable() {
      this.enabledConfig.setValue(true);
      this.onEnable();
      if ((Boolean)this.notifyConfig.getValue() && mc.field_1687 != null) {
         ChatUtil.clientSendMessage("§a[+] §f" + this.getName(), this.hashCode());
      }

   }

   public void disable() {
      this.enabledConfig.setValue(false);
      this.onDisable();
      if ((Boolean)this.notifyConfig.getValue() && mc.field_1687 != null) {
         ChatUtil.clientSendMessage("§c[-] §f" + this.getName(), this.hashCode());
      }

   }

   protected void onEnable() {
   }

   protected void onDisable() {
   }

   public void keybind(int keycode) {
      this.keybindingConfig.setContainer(this);
      ((MacroConfig)this.keybindingConfig).setValue(keycode);
   }

   public boolean isEnabled() {
      return (Boolean)this.enabledConfig.getValue();
   }

   public Macro getKeybinding() {
      return this.keybindingConfig.getValue();
   }

   public void setNotify(boolean notify) {
      this.notifyConfig.setValue(notify);
   }

   public boolean getNotify() {
      return (Boolean)this.notifyConfig.getValue();
   }

   public Animation getAnimation() {
      return this.animation;
   }
}
