package net.hachimi.client.init;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import net.hachimi.client.Hachimi;
import net.hachimi.client.impl.font.AWTFontRenderer;
import net.hachimi.client.impl.font.VanillaTextRenderer;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;

public class Fonts {
   public static final VanillaTextRenderer VANILLA = new VanillaTextRenderer();
   public static final String DEFAULT_FONT_FILE_PATH = "assets/hachimiclient/font/verdana.ttf";
   public static String FONT_FILE_PATH = "assets/hachimiclient/font/verdana.ttf";
   public static AWTFontRenderer CLIENT;
   public static AWTFontRenderer CLIENT_UNSCALED;
   public static float FONT_SIZE = 9.0F;
   private static boolean initialized;

   public static void init() {
      if (!initialized) {
         Hachimi.CONFIG.loadFonts();
         loadFonts();
         Hachimi.info("Loaded fonts!");
         initialized = true;
      }
   }

   public static void loadFonts() {
      try {
         class_2960 identifier = class_2960.method_60655("hachimiclient", "font/verdana.ttf");
         InputStream stream = ((class_3298)class_310.method_1551().method_1478().method_14486(identifier).get()).method_14482();
         CLIENT = new AWTFontRenderer((InputStream)(FONT_FILE_PATH.startsWith("assets") ? stream : new FileInputStream(FONT_FILE_PATH)), FONT_SIZE);
         CLIENT_UNSCALED = new AWTFontRenderer((InputStream)(FONT_FILE_PATH.startsWith("assets") ? stream : new FileInputStream(FONT_FILE_PATH)), 9.0F);
      } catch (IOException var2) {
      }

   }

   public static void closeFonts() {
      CLIENT.close();
      CLIENT_UNSCALED.close();
   }

   public static void setSize(float size) {
      FONT_SIZE = size;

      try {
         CLIENT = new AWTFontRenderer(new FileInputStream(FONT_FILE_PATH), FONT_SIZE);
      } catch (IOException var2) {
      }

   }

   public static boolean isInitialized() {
      return initialized;
   }
}
